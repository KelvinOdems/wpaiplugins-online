=== AutoSSL & Let's Encrypt Manager for cPanel ===
Contributors: kelvinodems
Tags: ssl, letsencrypt, cpanel, autossl, https
Requires at least: 5.8
Tested up to: 7.1
Stable tag: 1.2.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Issue, renew, and monitor 90-day Let's Encrypt & AutoSSL certificates via cPanel UAPI and ACME v2, inspect live SSL status, and enforce HTTPS safely.

== Description ==

**AutoSSL & Let's Encrypt Manager for cPanel** lets site administrators issue, renew, and monitor SSL certificates directly from the WordPress Admin dashboard using the cPanel UAPI and a built-in Let's Encrypt ACME v2 fallback client.

= Key Features =
* **cPanel UAPI Integration:** Uses encrypted cPanel API Tokens (`AES-256-CBC` with WordPress security salts) over port 2083—no plain-text cPanel passwords stored.
* **Automatic ACME v2 Fallback:** If your shared hosting provider disables the `autossl` feature in cPanel, the plugin automatically issues a free 90-day Let's Encrypt certificate via HTTP-01 challenge and installs it into cPanel via `SSL::install_ssl`.
* **Port 443 Pre-Flight Guard:** Verifies that your site responds with a valid TLS certificate before enabling 301 HTTPS redirects, preventing redirect loops.
* **Automated WP-Cron Renewal:** Checks certificate expiration daily and triggers automatic renewal before your configurable expiry threshold.

== External Services ==

This plugin connects to the following external services ONLY when explicitly configured and triggered by the site administrator:

1. **User's Own cPanel Server UAPI (`https://<your-cpanel-host>:2083/execute/SSL/...`)**
   * **Purpose:** To inspect installed SSL certificates (`SSL::installed_hosts`), trigger AutoSSL (`SSL::start_autossl_check`), check DCV diagnostics (`SSL::get_autossl_problems`), and install issued SSL certificates (`SSL::install_ssl`).
   * **Data Sent:** Your configured cPanel username, API token (in the `Authorization` header), and domain certificate PEM data when installing a certificate.

2. **Let's Encrypt Production ACME v2 API (`https://acme-v02.api.letsencrypt.org/directory`)**
   * **Purpose:** Used as an automatic fallback when your hosting provider has disabled cPanel's native `autossl` feature, to issue a free 90-day SSL certificate for your domain.
   * **Data Sent:** Your site's domain name (`identifiers`), your WordPress administrator email address (for Let's Encrypt expiry notifications), and a locally generated Certificate Signing Request (CSR).
   * **Terms & Privacy:** [Let's Encrypt Subscriber Agreement & Privacy Policy](https://letsencrypt.org/repository/).

== Installation ==

1. Upload the `cpanel-autossl-manager` folder to `/wp-content/plugins/` or upload `cpanel-autossl-manager.zip` via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Navigate to **cPanel AutoSSL** in the admin sidebar, enter your cPanel Host, Username, and cPanel API Token, and click **Save & Verify UAPI Connection**.

== Changelog ==

= 1.2.1 =
* Added `readme.txt` with External Services disclosure and WordPress.org Plugin Guidelines compliance improvements (`WP_Filesystem`, `wp_delete_file`, trademark-compliant naming).

= 1.2.0 =
* Redesigned admin dashboard with a modern light UI and inline SVG icons.

= 1.1.0 =
* Added built-in Let's Encrypt ACME v2 HTTP-01 fallback client for hosts where cPanel `autossl` is disabled.

= 1.0.0 =
* Initial release.
