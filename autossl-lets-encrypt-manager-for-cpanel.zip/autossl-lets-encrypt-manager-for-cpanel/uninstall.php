<?php
/**
 * Uninstall cPanel AutoSSL Manager.
 *
 * Cleans up encrypted options, cached status, and scheduled cron hooks.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'cam_uapi_settings' );
delete_option( 'cam_ssl_status_cache' );
delete_option( 'cam_ssl_activity_log' );
delete_option( 'cam_acme_account_data' );
delete_option( 'cam_acme_http_challenges' );

wp_clear_scheduled_hook( 'cam_daily_ssl_health_check' );
