<?php
/**
 * Plugin Name:       AutoSSL & Let's Encrypt Manager for cPanel
 * Plugin URI:        https://wpaiplugins.online/plugins/autossl-lets-encrypt-manager-for-cpanel
 * Description:       Issue, renew, and monitor Let's Encrypt & AutoSSL certificates via cPanel UAPI and ACME v2, inspect live SSL status, and enforce HTTPS safely.
 * Version:           1.2.2
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Kelvin Odems
 * Author URI:        https://wpaiplugins.online
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       autossl-lets-encrypt-manager-for-cpanel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CAM_VERSION', '1.2.2' );
define( 'CAM_PLUGIN_FILE', __FILE__ );
define( 'CAM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CAM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CAM_OPTION_SETTINGS', 'cam_uapi_settings' );
define( 'CAM_OPTION_STATUS_CACHE', 'cam_ssl_status_cache' );
define( 'CAM_OPTION_ACTIVITY_LOG', 'cam_ssl_activity_log' );

require_once CAM_PLUGIN_DIR . 'includes/class-cam-crypto.php';
require_once CAM_PLUGIN_DIR . 'includes/class-cam-uapi-client.php';
require_once CAM_PLUGIN_DIR . 'includes/class-cam-acme-client.php';
require_once CAM_PLUGIN_DIR . 'includes/class-cam-ssl-service.php';
require_once CAM_PLUGIN_DIR . 'includes/class-cam-cron.php';
require_once CAM_PLUGIN_DIR . 'includes/class-cam-admin.php';

/**
 * Main plugin bootstrap class.
 */
final class CPanel_AutoSSL_Manager {

	/**
	 * Singleton instance.
	 *
	 * @var CPanel_AutoSSL_Manager|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return CPanel_AutoSSL_Manager
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Initialize hooks.
	 */
	private function __construct() {
		CAM_ACME_Client::init();
		CAM_Cron::init();
		if ( is_admin() ) {
			CAM_Admin::init();
		}
		add_action( 'template_redirect', array( $this, 'maybe_force_https_redirect' ), 1 );
	}

	/**
	 * Optional front-end HTTPS redirection when enabled and verified safe.
	 */
	public function maybe_force_https_redirect() {
		if ( is_ssl() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		// Emergency bypass via query string ?cam_no_https=1
		if ( isset( $_GET['cam_no_https'] ) && '1' === $_GET['cam_no_https'] ) {
			return;
		}

		$settings = get_option( CAM_OPTION_SETTINGS, array() );
		if ( empty( $settings['force_https'] ) ) {
			return;
		}

		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		if ( ! empty( $host ) ) {
			wp_safe_redirect( 'https://' . $host . $uri, 301 );
			exit;
		}
	}

	/**
	 * Plugin activation hook.
	 */
	public static function activate() {
		CAM_Cron::schedule_events();
	}

	/**
	 * Plugin deactivation hook.
	 */
	public static function deactivate() {
		CAM_Cron::clear_events();
	}
}

register_activation_hook( __FILE__, array( 'CPanel_AutoSSL_Manager', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CPanel_AutoSSL_Manager', 'deactivate' ) );

CPanel_AutoSSL_Manager::instance();
