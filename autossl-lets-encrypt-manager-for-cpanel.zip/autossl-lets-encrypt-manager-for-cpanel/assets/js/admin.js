(function ($) {
	'use strict';

	function showNotice(type, message) {
		var cls = type === 'error' ? 'notice-error' : 'notice-success';
		var html = '<div class="notice ' + cls + ' is-dismissible"><p>' + $('<div>').text(message).html() + '</p></div>';
		$('#cam-notice-area').html(html);
	}

	function renderLogs(logs) {
		if (!Array.isArray(logs) || !logs.length) {
			return;
		}
		var html = '';
		logs.forEach(function (entry) {
			html += '<div class="cam-log-item cam-log-' + entry.type + '">' +
				'<span class="cam-log-dot"></span>' +
				'<span class="cam-log-time">' + $('<div>').text(entry.time).html() + '</span>' +
				'<span class="cam-log-msg">' + $('<div>').text(entry.message).html() + '</span>' +
				'</div>';
		});
		$('#cam-log-console').html(html);
	}

	function updateTelemetryUI(telemetry) {
		if (!telemetry) {
			return;
		}
		var certValid = false;
		if (telemetry.matching_cert) {
			var c = telemetry.matching_cert;
			$('#cam-cert-issuer').text(c.issuer || 'Unknown');
			$('#cam-cert-expiry').text((c.expiry_date || '') + (c.days_left !== null ? ' (' + c.days_left + ' days left)' : ''));
			$('#cam-cert-autossl').text(c.is_autossl ? 'Auto-Renewing (90-Day)' : 'Custom Certificate');

			certValid = !c.is_self_signed && (c.days_left === null || c.days_left > 0);
			var $certBadge = $('#cam-cert-badge');
			$certBadge
				.removeClass('cam-badge-success cam-badge-warning cam-badge-danger')
				.addClass(certValid ? 'cam-badge-success' : 'cam-badge-warning')
				.text(certValid ? 'Active SSL' : 'Action Needed');
		}

		var probeReachable = telemetry.https_probe && telemetry.https_probe.reachable;
		var tlsReady = probeReachable || certValid;
		var $tlsBadge = $('#cam-tls-badge');
		$tlsBadge
			.removeClass('cam-badge-success cam-badge-danger')
			.addClass(tlsReady ? 'cam-badge-success' : 'cam-badge-danger')
			.text(tlsReady ? 'TLS Verified' : 'TLS Unverified');

		if (probeReachable) {
			$('#cam-probe-msg').text(telemetry.https_probe.message);
		} else if (certValid) {
			$('#cam-probe-msg').text('Valid SSL certificate is installed in cPanel and active for your domain.');
		} else if (telemetry.https_probe && telemetry.https_probe.message) {
			$('#cam-probe-msg').text(telemetry.https_probe.message);
		}

		if (telemetry.checked_at) {
			$('#cam-last-checked').text('Last checked: ' + telemetry.checked_at);
		}
	}

	// Save cPanel UAPI Settings
	$('#cam-settings-form').on('submit', function (e) {
		e.preventDefault();
		var $btn = $('#cam-btn-save-settings');
		var orig = $btn.html();
		$btn.prop('disabled', true).text('Verifying UAPI Connection...');

		var data = $(this).serialize() + '&action=cam_save_settings&nonce=' + encodeURIComponent(CAM_Config.nonce);
		$.post(CAM_Config.ajaxUrl, data, function (res) {
			$btn.prop('disabled', false).html(orig);
			if (res.success) {
				showNotice('success', res.data.message);
				updateTelemetryUI(res.data.telemetry);
				renderLogs(res.data.logs);
			} else {
				showNotice('error', (res.data && res.data.message) ? res.data.message : 'Connection failed.');
			}
		}).fail(function () {
			$btn.prop('disabled', false).html(orig);
			showNotice('error', 'Request failed. Please check your network or PHP error log.');
		});
	});

	// Trigger AutoSSL Check
	$('#cam-btn-autossl').on('click', function () {
		var $btn = $(this);
		var orig = $btn.html();
		$btn.prop('disabled', true).find('span').text('Issuing & Installing Let\'s Encrypt SSL...');

		$.post(CAM_Config.ajaxUrl, {
			action: 'cam_trigger_autossl',
			nonce: CAM_Config.nonce
		}, function (res) {
			$btn.prop('disabled', false).html(orig);
			if (res.success) {
				showNotice('success', res.data.message);
				updateTelemetryUI(res.data.telemetry);
				renderLogs(res.data.logs);
			} else {
				showNotice('error', (res.data && res.data.message) ? res.data.message : 'AutoSSL trigger failed.');
				if (res.data && res.data.logs) {
					renderLogs(res.data.logs);
				}
			}
		}).fail(function () {
			$btn.prop('disabled', false).html(orig);
			showNotice('error', 'Network error while contacting cPanel UAPI.');
		});
	});

	// Refresh Status
	$('#cam-btn-refresh').on('click', function () {
		var $btn = $(this);
		var orig = $btn.html();
		$btn.prop('disabled', true).find('span').text('Refreshing...');

		$.post(CAM_Config.ajaxUrl, {
			action: 'cam_refresh_telemetry',
			nonce: CAM_Config.nonce
		}, function (res) {
			$btn.prop('disabled', false).html(orig);
			if (res.success) {
				updateTelemetryUI(res.data.telemetry);
				renderLogs(res.data.logs);
				showNotice('success', 'SSL telemetry refreshed.');
			}
		});
	});

	// Toggle HTTPS Enforcement
	$('#cam-btn-save-https').on('click', function () {
		var $btn = $(this);
		var orig = $btn.text();
		$btn.prop('disabled', true).text('Verifying TLS...');

		$.post(CAM_Config.ajaxUrl, {
			action: 'cam_toggle_https_redirect',
			nonce: CAM_Config.nonce,
			enable_https: $('#cam-force-https').is(':checked') ? 1 : 0,
			update_wp_urls: $('#cam-update-wp-urls').is(':checked') ? 1 : 0
		}, function (res) {
			$btn.prop('disabled', false).text(orig);
			if (res.success) {
				showNotice('success', res.data.message);
				renderLogs(res.data.logs);
			} else {
				$('#cam-force-https').prop('checked', false);
				showNotice('error', (res.data && res.data.message) ? res.data.message : 'Could not enable HTTPS.');
			}
		});
	});

	// Install Custom SSL Certificate
	$('#cam-custom-ssl-form').on('submit', function (e) {
		e.preventDefault();
		var $btn = $(this).find('button[type="submit"]');
		var orig = $btn.text();
		$btn.prop('disabled', true).text('Installing via UAPI...');

		var data = $(this).serialize() + '&action=cam_install_custom_ssl&nonce=' + encodeURIComponent(CAM_Config.nonce);
		$.post(CAM_Config.ajaxUrl, data, function (res) {
			$btn.prop('disabled', false).text(orig);
			if (res.success) {
				showNotice('success', res.data.message);
				updateTelemetryUI(res.data.telemetry);
				renderLogs(res.data.logs);
			} else {
				showNotice('error', (res.data && res.data.message) ? res.data.message : 'Failed to install certificate.');
			}
		});
	});
})(jQuery);
