<?php
/**
 * Scheduled WP-Cron tasks for monitoring SSL certificate expiry and auto-triggering AutoSSL renewal.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CAM_Cron {

	/**
	 * Cron hook name.
	 */
	const HOOK = 'cam_daily_ssl_health_check';

	/**
	 * Register cron hook.
	 */
	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run_daily_check' ) );
	}

	/**
	 * Schedule daily check on activation.
	 */
	public static function schedule_events() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 300, 'daily', self::HOOK );
		}
	}

	/**
	 * Clear scheduled events on deactivation.
	 */
	public static function clear_events() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Execute daily SSL telemetry refresh and trigger AutoSSL if expiring within threshold.
	 */
	public static function run_daily_check() {
		$settings = get_option( CAM_OPTION_SETTINGS, array() );
		$service  = new CAM_SSL_Service();
		$status   = $service->get_full_ssl_telemetry( true );

		if ( empty( $status['uapi_connected'] ) ) {
			return;
		}

		$auto_renew = isset( $settings['auto_renew_threshold'] ) ? absint( $settings['auto_renew_threshold'] ) : 14;
		$cert       = $status['matching_cert'];

		$should_trigger = false;
		$reason         = '';

		if ( empty( $cert ) ) {
			$should_trigger = true;
			$reason         = 'No active SSL certificate matched for ' . $status['site_domain'];
		} elseif ( ! empty( $cert['is_self_signed'] ) ) {
			$should_trigger = true;
			$reason         = 'Current certificate is self-signed';
		} elseif ( isset( $cert['days_left'] ) && null !== $cert['days_left'] && $cert['days_left'] <= $auto_renew ) {
			$should_trigger = true;
			$reason         = sprintf( 'Certificate expires in %d days (threshold: %d days)', $cert['days_left'], $auto_renew );
		}

		if ( $should_trigger && ! empty( $settings['enable_auto_trigger'] ) ) {
			CAM_SSL_Service::log( 'info', 'WP-Cron AutoSSL Trigger: ' . $reason );
			$service->trigger_autossl_check();
		}
	}
}
