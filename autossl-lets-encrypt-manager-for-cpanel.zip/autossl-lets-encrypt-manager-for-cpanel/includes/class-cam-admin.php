<?php
/**
 * WordPress Admin UI and AJAX Controllers for cPanel AutoSSL Manager.
 * Features a clean, modern light-theme UI with inline Lucide SVG icons and proper WordPress notice isolation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CAM_Admin {

	/**
	 * Initialize admin hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );

		// AJAX endpoints
		add_action( 'wp_ajax_cam_save_settings', array( __CLASS__, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_cam_refresh_telemetry', array( __CLASS__, 'ajax_refresh_telemetry' ) );
		add_action( 'wp_ajax_cam_trigger_autossl', array( __CLASS__, 'ajax_trigger_autossl' ) );
		add_action( 'wp_ajax_cam_install_custom_ssl', array( __CLASS__, 'ajax_install_custom_ssl' ) );
		add_action( 'wp_ajax_cam_toggle_https_redirect', array( __CLASS__, 'ajax_toggle_https_redirect' ) );
	}

	/**
	 * Register top-level menu item.
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'cPanel AutoSSL Manager', 'autossl-lets-encrypt-manager-for-cpanel' ),
			__( 'cPanel AutoSSL', 'autossl-lets-encrypt-manager-for-cpanel' ),
			'manage_options',
			'autossl-lets-encrypt-manager-for-cpanel',
			array( __CLASS__, 'render_dashboard' ),
			'dashicons-lock',
			81
		);
	}

	/**
	 * Enqueue admin CSS & JS only on our plugin screen.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'toplevel_page_cpanel-autossl-manager' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'cam-admin-css',
			CAM_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			CAM_VERSION
		);

		wp_enqueue_script(
			'cam-admin-js',
			CAM_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			CAM_VERSION,
			true
		);

		wp_localize_script(
			'cam-admin-js',
			'CAM_Config',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'cam_admin_nonce' ),
				'domain'  => CAM_SSL_Service::get_site_domain(),
			)
		);
	}

	/**
	 * Verify admin capability and AJAX nonce.
	 */
	private static function verify_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'autossl-lets-encrypt-manager-for-cpanel' ) ), 403 );
		}
		check_ajax_referer( 'cam_admin_nonce', 'nonce' );
	}

	/**
	 * AJAX: Save cPanel UAPI connection settings and test connection.
	 */
	public static function ajax_save_settings() {
		self::verify_request();

		$existing = get_option( CAM_OPTION_SETTINGS, array() );
		$host     = isset( $_POST['cpanel_host'] ) ? sanitize_text_field( wp_unslash( $_POST['cpanel_host'] ) ) : '';
		$port     = isset( $_POST['cpanel_port'] ) ? absint( $_POST['cpanel_port'] ) : 2083;
		$user     = isset( $_POST['cpanel_user'] ) ? sanitize_text_field( wp_unslash( $_POST['cpanel_user'] ) ) : '';
		$token    = isset( $_POST['api_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['api_token'] ) ) ) : '';
		$verify   = ! empty( $_POST['verify_ssl'] );
		$auto_trg = ! empty( $_POST['enable_auto_trigger'] );
		$thresh   = isset( $_POST['auto_renew_threshold'] ) ? max( 3, min( 60, absint( $_POST['auto_renew_threshold'] ) ) ) : 14;

		$token_enc = isset( $existing['api_token_enc'] ) ? $existing['api_token_enc'] : '';
		if ( ! empty( $token ) && '••••••••••••••••' !== $token ) {
			$token_enc = CAM_Crypto::encrypt( $token );
		}

		$new_settings = array(
			'cpanel_host'          => $host,
			'cpanel_port'          => $port > 0 ? $port : 2083,
			'cpanel_user'          => $user,
			'api_token_enc'        => $token_enc,
			'verify_ssl'           => $verify,
			'enable_auto_trigger'  => $auto_trg,
			'auto_renew_threshold' => $thresh,
			'force_https'          => ! empty( $existing['force_https'] ),
		);

		update_option( CAM_OPTION_SETTINGS, $new_settings, false );
		CAM_SSL_Service::log( 'info', 'Updated cPanel UAPI connection settings for user: ' . $user );

		$service   = new CAM_SSL_Service();
		$telemetry = $service->get_full_ssl_telemetry( true );

		if ( ! empty( $telemetry['uapi_error'] ) ) {
			wp_send_json_error(
				array(
					'message'   => $telemetry['uapi_error'],
					'telemetry' => $telemetry,
				)
			);
		}

		wp_send_json_success(
			array(
				'message'   => __( 'cPanel UAPI settings saved and connection verified!', 'autossl-lets-encrypt-manager-for-cpanel' ),
				'telemetry' => $telemetry,
				'logs'      => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
			)
		);
	}

	/**
	 * AJAX: Refresh live SSL telemetry from cPanel UAPI.
	 */
	public static function ajax_refresh_telemetry() {
		self::verify_request();

		$service   = new CAM_SSL_Service();
		$telemetry = $service->get_full_ssl_telemetry( true );

		wp_send_json_success(
			array(
				'telemetry' => $telemetry,
				'logs'      => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
			)
		);
	}

	/**
	 * AJAX: Trigger cPanel AutoSSL / Let's Encrypt issuance & renewal check.
	 */
	public static function ajax_trigger_autossl() {
		self::verify_request();

		$service = new CAM_SSL_Service();
		$result  = $service->trigger_autossl_check();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'logs'    => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
				)
			);
		}

		$telemetry = $service->get_full_ssl_telemetry( true );
		$msg       = is_array( $result ) && ! empty( $result['message'] )
			? $result['message']
			: __( 'AutoSSL / Let\'s Encrypt check completed!', 'autossl-lets-encrypt-manager-for-cpanel' );

		wp_send_json_success(
			array(
				'message'   => $msg,
				'telemetry' => $telemetry,
				'logs'      => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
			)
		);
	}

	/**
	 * AJAX: Install custom CRT + Private Key via UAPI (`SSL::install_ssl`).
	 */
	public static function ajax_install_custom_ssl() {
		self::verify_request();

		$domain   = isset( $_POST['domain'] ) ? sanitize_text_field( wp_unslash( $_POST['domain'] ) ) : CAM_SSL_Service::get_site_domain();
		$cert     = isset( $_POST['cert'] ) ? sanitize_textarea_field( wp_unslash( $_POST['cert'] ) ) : '';
		$key      = isset( $_POST['key'] ) ? sanitize_textarea_field( wp_unslash( $_POST['key'] ) ) : '';
		$cabundle = isset( $_POST['cabundle'] ) ? sanitize_textarea_field( wp_unslash( $_POST['cabundle'] ) ) : '';

		if ( empty( $domain ) || empty( $cert ) || empty( $key ) ) {
			wp_send_json_error( array( 'message' => __( 'Domain, Certificate (CRT), and Private Key (KEY) are required.', 'autossl-lets-encrypt-manager-for-cpanel' ) ) );
		}

		$service = new CAM_SSL_Service();
		$res     = $service->install_custom_certificate( $domain, $cert, $key, $cabundle );

		if ( is_wp_error( $res ) ) {
			wp_send_json_error(
				array(
					'message' => $res->get_error_message(),
					'logs'    => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
				)
			);
		}

		$telemetry = $service->get_full_ssl_telemetry( true );
		wp_send_json_success(
			array(
				'message'   => __( 'SSL certificate installed successfully via cPanel UAPI!', 'autossl-lets-encrypt-manager-for-cpanel' ),
				'telemetry' => $telemetry,
				'logs'      => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
			)
		);
	}

	/**
	 * AJAX: Safely toggle Force HTTPS redirect and update siteurl/home after pre-flight HTTPS check.
	 */
	public static function ajax_toggle_https_redirect() {
		self::verify_request();

		$enable      = ! empty( $_POST['enable_https'] );
		$update_urls = ! empty( $_POST['update_wp_urls'] );
		$settings    = get_option( CAM_OPTION_SETTINGS, array() );
		$service     = new CAM_SSL_Service();

		if ( $enable ) {
			$telemetry = $service->get_full_ssl_telemetry( true );
			$probe     = $telemetry['https_probe'];
			$cert      = $telemetry['matching_cert'];
			$cert_ok   = $cert && empty( $cert['is_self_signed'] ) && ( null === $cert['days_left'] || $cert['days_left'] > 0 );

			if ( empty( $probe['reachable'] ) && ! $cert_ok ) {
				wp_send_json_error(
					array(
						'message'   => sprintf(
							/* translators: %s: error detail */
							__( 'Safety Guard Blocked HTTPS Enforcement: Your site did not respond with a valid SSL certificate over port 443 (%s). Run AutoSSL and wait for issuance before forcing HTTPS.', 'autossl-lets-encrypt-manager-for-cpanel' ),
							$probe['message']
						),
						'telemetry' => $telemetry,
					)
				);
			}

			if ( $update_urls ) {
				$home    = set_url_scheme( get_option( 'home' ), 'https' );
				$siteurl = set_url_scheme( get_option( 'siteurl' ), 'https' );
				update_option( 'home', $home );
				update_option( 'siteurl', $siteurl );
			}
			$settings['force_https'] = true;
			CAM_SSL_Service::log( 'success', 'Enabled Force HTTPS after passing SSL verification check.' );
		} else {
			$settings['force_https'] = false;
			CAM_SSL_Service::log( 'info', 'Disabled Force HTTPS redirect.' );
		}

		update_option( CAM_OPTION_SETTINGS, $settings, false );

		wp_send_json_success(
			array(
				'message'     => $enable
					? __( 'HTTPS enforcement enabled safely!', 'autossl-lets-encrypt-manager-for-cpanel' )
					: __( 'HTTPS enforcement disabled.', 'autossl-lets-encrypt-manager-for-cpanel' ),
				'force_https' => ! empty( $settings['force_https'] ),
				'logs'        => get_option( CAM_OPTION_ACTIVITY_LOG, array() ),
			)
		);
	}

	/**
	 * Render crisp inline SVG icon by name (Lucide standard UI/UX icons).
	 *
	 * @param string $name Icon identifier.
	 * @return string SVG markup.
	 */
	public static function icon( $name ) {
		$icons = array(
			'shield-check' => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>',
			'refresh-cw'   => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>',
			'key-round'    => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/><circle cx="16.5" cy="7.5" r=".5" fill="currentColor"/></svg>',
			'lock'         => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
			'globe'        => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>',
			'activity'     => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/></svg>',
			'server'       => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/></svg>',
			'file-key'     => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><circle cx="10" cy="16" r="2"/><path d="m16 10-4.5 4.5"/><path d="m15 11 1 1"/></svg>',
			'check-circle' => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>',
			'clock'        => '<svg class="cam-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
		);
		return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
	}

	/**
	 * Render the Admin Dashboard page.
	 */
	public static function render_dashboard() {
		$settings  = get_option( CAM_OPTION_SETTINGS, array() );
		$telemetry = get_option( CAM_OPTION_STATUS_CACHE, array() );
		$logs      = get_option( CAM_OPTION_ACTIVITY_LOG, array() );
		$client    = new CAM_UAPI_Client();

		if ( empty( $telemetry ) ) {
			$service   = new CAM_SSL_Service( $client );
			$telemetry = $service->get_full_ssl_telemetry( false );
		}

		$host       = ! empty( $settings['cpanel_host'] ) ? $settings['cpanel_host'] : $client->detect_default_host();
		$port       = ! empty( $settings['cpanel_port'] ) ? (int) $settings['cpanel_port'] : 2083;
		$user       = ! empty( $settings['cpanel_user'] ) ? $settings['cpanel_user'] : '';
		$has_token  = ! empty( $settings['api_token_enc'] );
		$verify_ssl = ! empty( $settings['verify_ssl'] );
		$auto_trg   = isset( $settings['enable_auto_trigger'] ) ? (bool) $settings['enable_auto_trigger'] : true;
		$threshold  = ! empty( $settings['auto_renew_threshold'] ) ? (int) $settings['auto_renew_threshold'] : 14;
		$force_ssl  = ! empty( $settings['force_https'] );
		$cert       = isset( $telemetry['matching_cert'] ) ? $telemetry['matching_cert'] : null;
		$probe      = isset( $telemetry['https_probe'] ) ? $telemetry['https_probe'] : array( 'reachable' => false, 'message' => '' );
		$cert_valid = $cert && empty( $cert['is_self_signed'] ) && ( null === $cert['days_left'] || $cert['days_left'] > 0 );
		$tls_ready  = ! empty( $probe['reachable'] ) || $cert_valid;
		?>
		<div class="wrap cam-wrap">
			<!-- Anchor h1 so third-party WP Admin notices render cleanly above our UI banner -->
			<h1 class="wp-heading-inline screen-reader-text"><?php esc_html_e( 'cPanel AutoSSL Manager', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h1>
			<hr class="wp-header-end">

			<div class="cam-header">
				<div class="cam-header-brand">
					<div class="cam-brand-icon">
						<?php echo self::icon( 'key-round' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
					<div>
						<h2 class="cam-title"><?php esc_html_e( 'cPanel AutoSSL & Let\'s Encrypt Manager', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h2>
						<p class="cam-subtitle">
							<?php esc_html_e( 'Issue, renew, and monitor 90-day SSL certificates via cPanel UAPI & ACME v2 without leaving WordPress.', 'autossl-lets-encrypt-manager-for-cpanel' ); ?>
						</p>
					</div>
				</div>
				<div class="cam-header-actions">
					<button type="button" id="cam-btn-refresh" class="cam-btn cam-btn-outline">
						<?php echo self::icon( 'refresh-cw' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Refresh Status', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
					</button>
					<button type="button" id="cam-btn-autossl" class="cam-btn cam-btn-primary">
						<?php echo self::icon( 'lock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Run AutoSSL / Let\'s Encrypt Now', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
					</button>
				</div>
			</div>

			<div id="cam-notice-area"></div>

			<!-- Row 1: 3 Equal-Height Status Cards -->
			<div class="cam-grid-3">
				<!-- Card 1: Active Domain Certificate -->
				<div class="cam-card">
					<div class="cam-card-header">
						<div class="cam-card-title">
							<span class="cam-icon-box cam-icon-blue"><?php echo self::icon( 'lock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<h3><?php esc_html_e( 'Active Domain Certificate', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h3>
						</div>
						<span id="cam-cert-badge" class="cam-badge <?php echo $cert_valid ? 'cam-badge-success' : 'cam-badge-warning'; ?>">
							<?php echo $cert_valid ? esc_html__( 'Active SSL', 'autossl-lets-encrypt-manager-for-cpanel' ) : esc_html__( 'Action Needed', 'autossl-lets-encrypt-manager-for-cpanel' ); ?>
						</span>
					</div>
					<div class="cam-card-body" id="cam-cert-summary">
						<div class="cam-kv">
							<span><?php esc_html_e( 'Primary Domain', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
							<strong><?php echo esc_html( CAM_SSL_Service::get_site_domain() ); ?></strong>
						</div>
						<div class="cam-kv">
							<span><?php esc_html_e( 'Certificate Issuer', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
							<strong id="cam-cert-issuer"><?php echo $cert ? esc_html( $cert['issuer'] ) : esc_html__( 'Not detected yet', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></strong>
						</div>
						<div class="cam-kv">
							<span><?php esc_html_e( 'Expiration Date', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
							<strong id="cam-cert-expiry">
								<?php
								if ( $cert ) {
									echo esc_html( $cert['expiry_date'] . ' (' . $cert['days_left'] . ' days left)' );
								} else {
									esc_html_e( '—', 'autossl-lets-encrypt-manager-for-cpanel' );
								}
								?>
							</strong>
						</div>
						<div class="cam-kv">
							<span><?php esc_html_e( 'Renewal Mode', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
							<strong id="cam-cert-autossl"><?php echo $cert ? ( $cert['is_autossl'] ? esc_html__( 'Auto-Renewing (90-Day)', 'autossl-lets-encrypt-manager-for-cpanel' ) : esc_html__( 'Custom Certificate', 'autossl-lets-encrypt-manager-for-cpanel' ) ) : '—'; ?></strong>
						</div>
					</div>
				</div>

				<!-- Card 2: Port 443 Pre-Flight & HTTPS Guard -->
				<div class="cam-card">
					<div class="cam-card-header">
						<div class="cam-card-title">
							<span class="cam-icon-box cam-icon-emerald"><?php echo self::icon( 'globe' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<h3><?php esc_html_e( 'HTTPS Routing & Pre-Flight', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h3>
						</div>
						<span id="cam-tls-badge" class="cam-badge <?php echo $tls_ready ? 'cam-badge-success' : 'cam-badge-danger'; ?>">
							<?php echo $tls_ready ? esc_html__( 'TLS Verified', 'autossl-lets-encrypt-manager-for-cpanel' ) : esc_html__( 'TLS Unverified', 'autossl-lets-encrypt-manager-for-cpanel' ); ?>
						</span>
					</div>
					<div class="cam-card-body cam-flex-col">
						<p class="cam-muted" id="cam-probe-msg">
							<?php
							if ( ! empty( $probe['reachable'] ) ) {
								echo esc_html( $probe['message'] );
							} elseif ( $cert_valid ) {
								esc_html_e( 'Valid SSL certificate is installed in cPanel and active for your domain.', 'autossl-lets-encrypt-manager-for-cpanel' );
							} else {
								echo esc_html( $probe['message'] );
							}
							?>
						</p>
						<div class="cam-checks-group">
							<label class="cam-toggle-row">
								<input type="checkbox" id="cam-force-https" <?php checked( $force_ssl ); ?> />
								<span><?php esc_html_e( 'Force 301 HTTPS Redirect across site', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
							</label>
							<label class="cam-toggle-row">
								<input type="checkbox" id="cam-update-wp-urls" checked />
								<span><?php esc_html_e( 'Update WordPress Site URLs to https://', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
							</label>
						</div>
						<div class="cam-card-footer-action">
							<button type="button" id="cam-btn-save-https" class="cam-btn cam-btn-outline cam-btn-sm">
								<?php esc_html_e( 'Apply HTTPS Routing', 'autossl-lets-encrypt-manager-for-cpanel' ); ?>
							</button>
							<span class="cam-help-inline"><?php esc_html_e( 'Bypass: ?cam_no_https=1', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
						</div>
					</div>
				</div>

				<!-- Card 3: AutoSSL Queue & DCV Diagnostics -->
				<div class="cam-card">
					<div class="cam-card-header">
						<div class="cam-card-title">
							<span class="cam-icon-box cam-icon-indigo"><?php echo self::icon( 'activity' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<h3><?php esc_html_e( 'DCV & Renewal Diagnostics', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h3>
						</div>
						<span class="cam-badge cam-badge-neutral"><?php esc_html_e( 'Healthy', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
					</div>
					<div class="cam-card-body cam-flex-col" id="cam-diagnostics-box">
						<?php if ( ! empty( $telemetry['problems'] ) ) : ?>
							<div class="cam-alert cam-alert-warning">
								<strong><?php esc_html_e( 'DCV / AutoSSL Problems Reported:', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></strong>
								<ul>
									<?php foreach ( array_slice( $telemetry['problems'], 0, 3 ) as $prob ) : ?>
										<li><?php echo esc_html( ( isset( $prob['domain'] ) ? $prob['domain'] . ': ' : '' ) . ( isset( $prob['problem'] ) ? $prob['problem'] : wp_json_encode( $prob ) ) ); ?></li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php else : ?>
							<div class="cam-ok-box">
								<?php echo self::icon( 'check-circle' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<div>
									<strong><?php esc_html_e( 'Domain Validation Ready', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></strong>
									<p><?php esc_html_e( 'No pending AutoSSL queue blockers or HTTP-01 DCV validation errors detected.', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></p>
								</div>
							</div>
						<?php endif; ?>
						<div class="cam-timestamp-bar">
							<?php echo self::icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span id="cam-last-checked">
								<?php
								printf(
									/* translators: %s: timestamp */
									esc_html__( 'Last checked: %s', 'autossl-lets-encrypt-manager-for-cpanel' ),
									! empty( $telemetry['checked_at'] ) ? esc_html( $telemetry['checked_at'] ) : esc_html__( 'Never', 'autossl-lets-encrypt-manager-for-cpanel' )
								);
								?>
							</span>
						</div>
					</div>
				</div>
			</div>

			<!-- Row 2: Two Equal-Height Aligned Configuration & Activity Cards -->
			<div class="cam-grid-2">
				<!-- Left Card: cPanel UAPI Configuration -->
				<div class="cam-card">
					<div class="cam-card-header">
						<div class="cam-card-title">
							<span class="cam-icon-box cam-icon-blue"><?php echo self::icon( 'server' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<h2><?php esc_html_e( 'cPanel UAPI Connection Settings', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h2>
						</div>
						<span class="cam-badge cam-badge-neutral"><?php esc_html_e( 'AES-256 Encrypted', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
					</div>
					<div class="cam-card-body">
						<p class="cam-muted">
							<?php esc_html_e( 'In cPanel, navigate to Security → Manage API Tokens to create a token. Credentials are encrypted using your WordPress security salts.', 'autossl-lets-encrypt-manager-for-cpanel' ); ?>
						</p>
						<form id="cam-settings-form">
							<div class="cam-form-row">
								<div class="cam-field">
									<label for="cam-host"><?php esc_html_e( 'cPanel Hostname / Domain', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<input type="text" id="cam-host" name="cpanel_host" value="<?php echo esc_attr( $host ); ?>" placeholder="yourdomain.com" required />
								</div>
								<div class="cam-field cam-field-small">
									<label for="cam-port"><?php esc_html_e( 'UAPI Port', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<input type="number" id="cam-port" name="cpanel_port" value="<?php echo esc_attr( $port ); ?>" required />
								</div>
							</div>

							<div class="cam-form-row">
								<div class="cam-field">
									<label for="cam-user"><?php esc_html_e( 'cPanel Username', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<input type="text" id="cam-user" name="cpanel_user" value="<?php echo esc_attr( $user ); ?>" placeholder="e.g. myhostinguser" required />
								</div>
								<div class="cam-field">
									<label for="cam-token"><?php esc_html_e( 'cPanel API Token', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<input type="password" id="cam-token" name="api_token" value="<?php echo $has_token ? '••••••••••••••••' : ''; ?>" placeholder="Paste cPanel API Token" required />
								</div>
							</div>

							<div class="cam-form-row">
								<div class="cam-field">
									<label for="cam-threshold"><?php esc_html_e( 'Auto-Renewal Threshold (Days Before Expiry)', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<input type="number" id="cam-threshold" name="auto_renew_threshold" value="<?php echo esc_attr( $threshold ); ?>" min="3" max="60" />
								</div>
							</div>

							<div class="cam-checks-group">
								<label class="cam-toggle-row">
									<input type="checkbox" name="enable_auto_trigger" value="1" <?php checked( $auto_trg ); ?> />
									<span><?php esc_html_e( 'Automatically renew SSL via WP-Cron when expiring within threshold', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
								</label>

								<label class="cam-toggle-row">
									<input type="checkbox" name="verify_ssl" value="1" <?php checked( $verify_ssl ); ?> />
									<span><?php esc_html_e( 'Strict Peer SSL Verification on Port 2083 (leave unchecked on shared cPanel hosts)', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
								</label>
							</div>

							<div class="cam-form-actions">
								<button type="submit" id="cam-btn-save-settings" class="cam-btn cam-btn-primary">
									<?php esc_html_e( 'Save & Verify UAPI Connection', 'autossl-lets-encrypt-manager-for-cpanel' ); ?>
								</button>
							</div>
						</form>
					</div>
				</div>

				<!-- Right Card: Activity Log & Manual Certificate Install -->
				<div class="cam-card">
					<div class="cam-card-header">
						<div class="cam-card-title">
							<span class="cam-icon-box cam-icon-indigo"><?php echo self::icon( 'file-key' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<h2><?php esc_html_e( 'Activity History & Custom SSL Upload', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h2>
						</div>
						<span class="cam-badge cam-badge-neutral"><?php esc_html_e( 'SSL::install_ssl', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></span>
					</div>
					<div class="cam-card-body cam-flex-col">
						<details class="cam-custom-cert-drawer">
							<summary><?php esc_html_e( 'Upload a Custom Certificate (CRT & Private Key) via cPanel UAPI', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></summary>
							<form id="cam-custom-ssl-form" class="cam-mt">
								<div class="cam-field">
									<label><?php esc_html_e( 'Target Domain', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<input type="text" name="domain" value="<?php echo esc_attr( CAM_SSL_Service::get_site_domain() ); ?>" required />
								</div>
								<div class="cam-form-row">
									<div class="cam-field">
										<label><?php esc_html_e( 'Certificate (CRT - PEM)', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
										<textarea name="cert" rows="3" placeholder="-----BEGIN CERTIFICATE-----"></textarea>
									</div>
									<div class="cam-field">
										<label><?php esc_html_e( 'Private Key (KEY - PEM)', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
										<textarea name="key" rows="3" placeholder="-----BEGIN PRIVATE KEY-----"></textarea>
									</div>
								</div>
								<div class="cam-field">
									<label><?php esc_html_e( 'CA Bundle (CABUNDLE - Optional)', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></label>
									<textarea name="cabundle" rows="2" placeholder="-----BEGIN CERTIFICATE-----"></textarea>
								</div>
								<button type="submit" class="cam-btn cam-btn-outline cam-btn-sm"><?php esc_html_e( 'Install Certificate to cPanel', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></button>
							</form>
						</details>

						<div class="cam-log-section">
							<div class="cam-log-header">
								<h3 class="cam-log-title"><?php esc_html_e( 'Recent UAPI & ACME Activity Log', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></h3>
							</div>
							<div class="cam-log-feed" id="cam-log-console">
								<?php if ( empty( $logs ) ) : ?>
									<div class="cam-log-empty"><?php esc_html_e( 'No SSL events recorded yet.', 'autossl-lets-encrypt-manager-for-cpanel' ); ?></div>
								<?php else : ?>
									<?php foreach ( $logs as $entry ) : ?>
										<div class="cam-log-item cam-log-<?php echo esc_attr( $entry['type'] ); ?>">
											<span class="cam-log-dot"></span>
											<span class="cam-log-time"><?php echo esc_html( $entry['time'] ); ?></span>
											<span class="cam-log-msg"><?php echo esc_html( $entry['message'] ); ?></span>
										</div>
									<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
