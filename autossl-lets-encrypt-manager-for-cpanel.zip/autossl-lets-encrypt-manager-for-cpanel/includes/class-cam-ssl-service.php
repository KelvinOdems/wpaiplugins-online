<?php
/**
 * High-level SSL & AutoSSL Service interacting with cPanel UAPI and local HTTPS probe.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CAM_SSL_Service {

	/**
	 * UAPI Client instance.
	 *
	 * @var CAM_UAPI_Client
	 */
	private $client;

	/**
	 * Constructor.
	 *
	 * @param CAM_UAPI_Client|null $client Optional custom UAPI client.
	 */
	public function __construct( $client = null ) {
		$this->client = $client instanceof CAM_UAPI_Client ? $client : new CAM_UAPI_Client();
	}

	/**
	 * Get current site's primary domain (without www. prefix normalized for matching).
	 *
	 * @return string
	 */
	public static function get_site_domain() {
		$parsed = wp_parse_url( home_url() );
		return ! empty( $parsed['host'] ) ? strtolower( $parsed['host'] ) : '';
	}

	/**
	 * Log an activity event to the rolling 50-entry plugin log.
	 *
	 * @param string $type    'info', 'success', 'warning', or 'error'.
	 * @param string $message Human-readable message.
	 */
	public static function log( $type, $message ) {
		$logs = get_option( CAM_OPTION_ACTIVITY_LOG, array() );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		array_unshift(
			$logs,
			array(
				'time'    => current_time( 'mysql' ),
				'type'    => sanitize_key( $type ),
				'message' => sanitize_text_field( $message ),
			)
		);

		$logs = array_slice( $logs, 0, 50 );
		update_option( CAM_OPTION_ACTIVITY_LOG, $logs, false );
	}

	/**
	 * Trigger cPanel AutoSSL check for the current user (`SSL::start_autossl_check`).
	 * If the hosting provider has disabled the "autossl" feature on the cPanel package,
	 * automatically falls back to Direct Let's Encrypt ACME v2 issuance + `SSL::install_ssl`!
	 *
	 * @return array|WP_Error
	 */
	public function trigger_autossl_check() {
		$result = $this->client->call( 'SSL', 'start_autossl_check' );
		if ( ! is_wp_error( $result ) ) {
			self::log( 'success', 'Triggered cPanel AutoSSL / Let\'s Encrypt check via UAPI.' );
			return array(
				'mode'    => 'cpanel_autossl',
				'message' => __( 'AutoSSL check started in cPanel! Let\'s Encrypt / AutoSSL is now validating your domain in the background.', 'autossl-lets-encrypt-manager-for-cpanel' ),
				'result'  => $result,
			);
		}

		$err_msg = $result->get_error_message();

		// Detect when host disabled "autossl" feature in cPanel Feature Manager
		if ( stripos( $err_msg, 'autossl' ) !== false || stripos( $err_msg, 'feature' ) !== false ) {
			self::log( 'warning', 'Hosting provider disabled cPanel AutoSSL feature ("' . $err_msg . '"). Switching to Direct Let\'s Encrypt ACME v2 Client + UAPI SSL::install_ssl...' );
			$acme     = new CAM_ACME_Client();
			$acme_res = $acme->issue_and_install_letsencrypt( $this->client, true );
			if ( is_wp_error( $acme_res ) ) {
				self::log( 'error', 'Direct Let\'s Encrypt ACME v2 issuance failed: ' . $acme_res->get_error_message() );
				return $acme_res;
			}

			return array(
				'mode'    => 'direct_acme_install',
				'message' => sprintf(
					/* translators: %s: comma-separated domain names */
					__( 'Your host disabled cPanel AutoSSL, so the plugin automatically issued a new 90-day Let\'s Encrypt SSL certificate directly via ACME v2 and installed it into cPanel for: %s!', 'autossl-lets-encrypt-manager-for-cpanel' ),
					implode( ', ', $acme_res['domains'] )
				),
				'result'  => $acme_res,
			);
		}

		self::log( 'error', 'AutoSSL trigger failed: ' . $err_msg );
		return $result;
	}

	/**
	 * Retrieve comprehensive SSL telemetry from cPanel UAPI + local HTTPS socket probe.
	 *
	 * @param bool $update_cache Whether to store in option cache.
	 * @return array
	 */
	public function get_full_ssl_telemetry( $update_cache = true ) {
		$site_domain = self::get_site_domain();
		$bare_domain = preg_replace( '/^www\./i', '', $site_domain );

		$telemetry = array(
			'checked_at'         => current_time( 'mysql' ),
			'site_domain'        => $site_domain,
			'uapi_connected'     => false,
			'uapi_error'         => '',
			'autossl_available'  => true,
			'matching_cert'      => null,
			'all_installed'      => array(),
			'pending_queue'      => array(),
			'problems'           => array(),
			'https_probe'        => $this->probe_live_https(),
		);

		if ( ! $this->client->is_configured() ) {
			$telemetry['uapi_error'] = __( 'cPanel UAPI credentials not configured yet.', 'autossl-lets-encrypt-manager-for-cpanel' );
			return $telemetry;
		}

		// 1. Fetch installed SSL hosts via SSL::installed_hosts
		$installed = $this->client->call( 'SSL', 'installed_hosts' );
		if ( is_wp_error( $installed ) ) {
			$telemetry['uapi_error'] = $installed->get_error_message();
			return $telemetry;
		}

		$telemetry['uapi_connected'] = true;
		$hosts_data                  = is_array( $installed['data'] ) ? $installed['data'] : array();

		foreach ( $hosts_data as $host_entry ) {
			$cert        = isset( $host_entry['certificate'] ) && is_array( $host_entry['certificate'] ) ? $host_entry['certificate'] : $host_entry;
			$servername  = isset( $host_entry['servername'] ) ? strtolower( $host_entry['servername'] ) : '';
			$domains     = isset( $cert['domains'] ) && is_array( $cert['domains'] ) ? array_map( 'strtolower', $cert['domains'] ) : array();
			$not_after   = isset( $cert['not_after'] ) ? (int) $cert['not_after'] : 0;
			$days_left   = $not_after > 0 ? (int) floor( ( $not_after - time() ) / DAY_IN_SECONDS ) : null;
			$issuer_org  = isset( $cert['issuer.organizationName'] ) ? $cert['issuer.organizationName'] : ( isset( $cert['issuer_organization_name'] ) ? $cert['issuer_organization_name'] : 'SSL Authority' );
			$is_autossl  = ! empty( $cert['is_autossl'] ) || stripos( $issuer_org, "Let's Encrypt" ) !== false || stripos( $issuer_org, 'cPanel' ) !== false || stripos( $issuer_org, 'Sectigo' ) !== false;

			$normalized = array(
				'servername'  => $servername,
				'domains'     => $domains,
				'issuer'      => $issuer_org,
				'not_after'   => $not_after,
				'expiry_date' => $not_after > 0 ? wp_date( 'Y-m-d H:i', $not_after ) : __( 'Unknown', 'autossl-lets-encrypt-manager-for-cpanel' ),
				'days_left'   => $days_left,
				'is_autossl'  => (bool) $is_autossl,
				'is_self_signed' => ! empty( $cert['is_self_signed'] ),
			);

			$telemetry['all_installed'][] = $normalized;

			if ( $servername === $site_domain || $servername === $bare_domain || in_array( $site_domain, $domains, true ) || in_array( $bare_domain, $domains, true ) ) {
				$telemetry['matching_cert'] = $normalized;
			}
		}

		// 2. Check AutoSSL Pending Queue (`SSL::get_autossl_pending_queue`)
		$queue_res = $this->client->call( 'SSL', 'get_autossl_pending_queue' );
		if ( ! is_wp_error( $queue_res ) && is_array( $queue_res['data'] ) ) {
			$telemetry['pending_queue'] = $queue_res['data'];
		}

		// 3. Check AutoSSL Problems (`SSL::get_autossl_problems`)
		$prob_res = $this->client->call( 'SSL', 'get_autossl_problems' );
		if ( ! is_wp_error( $prob_res ) && is_array( $prob_res['data'] ) ) {
			$telemetry['problems'] = $prob_res['data'];
		}

		if ( $update_cache ) {
			update_option( CAM_OPTION_STATUS_CACHE, $telemetry, false );
		}

		return $telemetry;
	}

	/**
	 * Probe the site's own HTTPS URL on port 443 to confirm SSL is reachable before forcing HTTPS.
	 *
	 * @return array
	 */
	public function probe_live_https() {
		$https_url = set_url_scheme( home_url( '/' ), 'https' );
		$response  = wp_remote_head(
			$https_url,
			array(
				'timeout'     => 10,
				'redirection' => 2,
				'sslverify'   => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'reachable' => false,
				'code'      => 0,
				'message'   => $response->get_error_message(),
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		return array(
			'reachable' => ( $code >= 200 && $code < 500 ),
			'code'      => $code,
			'message'   => sprintf(
				/* translators: %d: HTTP status code */
				__( 'HTTPS endpoint responded with valid TLS certificate (HTTP %d).', 'autossl-lets-encrypt-manager-for-cpanel' ),
				$code
			),
		);
	}

	/**
	 * Install an explicit SSL certificate via cPanel UAPI (`SSL::install_ssl`) if user pastes custom CRT/KEY.
	 *
	 * @param string $domain   Domain name.
	 * @param string $cert     PEM-encoded CRT.
	 * @param string $key      PEM-encoded Private Key.
	 * @param string $cabundle Optional PEM-encoded CA Bundle.
	 * @return array|WP_Error
	 */
	public function install_custom_certificate( $domain, $cert, $key, $cabundle = '' ) {
		$params = array(
			'domain' => sanitize_text_field( $domain ),
			'cert'   => trim( $cert ),
			'key'    => trim( $key ),
		);
		if ( ! empty( $cabundle ) ) {
			$params['cabundle'] = trim( $cabundle );
		}

		$result = $this->client->call( 'SSL', 'install_ssl', $params, 'POST' );
		if ( is_wp_error( $result ) ) {
			self::log( 'error', 'Custom SSL install failed for ' . $domain . ': ' . $result->get_error_message() );
			return $result;
		}

		self::log( 'success', 'Installed custom SSL certificate via cPanel UAPI for ' . $domain );
		return $result;
	}
}
