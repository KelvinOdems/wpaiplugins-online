<?php
/**
 * Direct ACME v2 Client (Let's Encrypt) + Local OpenSSL CSR & Key Generator:
 * Issues free 90-day SSL certificates via HTTP-01 challenge when the hosting provider
 * has disabled the cPanel "autossl" feature on the user's package, then installs
 * the certificate into cPanel via UAPI `SSL::install_ssl`.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CAM_ACME_Client {

	/**
	 * Let's Encrypt Production ACME v2 Directory URL.
	 */
	const DIRECTORY_URL = 'https://acme-v02.api.letsencrypt.org/directory';

	/**
	 * Option key for storing ACME account private key and URL.
	 */
	const OPT_ACCOUNT = 'cam_acme_account_data';

	/**
	 * Option key for active HTTP-01 challenge tokens.
	 */
	const OPT_CHALLENGES = 'cam_acme_http_challenges';

	/**
	 * Cached ACME directory endpoints.
	 *
	 * @var array|null
	 */
	private $directory = null;

	/**
	 * Replay-Nonce from last ACME response.
	 *
	 * @var string
	 */
	private $nonce = '';

	/**
	 * Account private key PEM.
	 *
	 * @var string
	 */
	private $account_key_pem = '';

	/**
	 * Account Kid URL.
	 *
	 * @var string
	 */
	private $account_kid = '';

	/**
	 * Register early hook to serve `/.well-known/acme-challenge/{token}` directly from WordPress
	 * and write physical files when possible.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'maybe_serve_acme_challenge' ), 1 );
	}

	/**
	 * Intercept `/.well-known/acme-challenge/<token>` requests if physical file wasn't served directly by Apache/LiteSpeed.
	 */
	public static function maybe_serve_acme_challenge() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		if ( strpos( $uri, '/.well-known/acme-challenge/' ) === false ) {
			return;
		}

		$parts = explode( '/.well-known/acme-challenge/', $uri );
		$token = isset( $parts[1] ) ? preg_replace( '/[^a-zA-Z0-9_\-]/', '', explode( '?', $parts[1] )[0] ) : '';
		if ( empty( $token ) ) {
			return;
		}

		$challenges = get_option( self::OPT_CHALLENGES, array() );
		if ( is_array( $challenges ) && ! empty( $challenges[ $token ] ) ) {
			status_header( 200 );
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo esc_html( $challenges[ $token ] );
			exit;
		}
	}

	/**
	 * Initialize WP_Filesystem safely.
	 *
	 * @return WP_Filesystem_Base|false
	 */
	private static function get_filesystem() {
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		return $wp_filesystem;
	}

	/**
	 * Write physical challenge file to ABSPATH/.well-known/acme-challenge/{token} AND store in WP option fallback.
	 *
	 * @param string $token            ACME token.
	 * @param string $key_authorization Key authorization string.
	 */
	public static function store_challenge( $token, $key_authorization ) {
		$token      = preg_replace( '/[^a-zA-Z0-9_\-]/', '', $token );
		$challenges = get_option( self::OPT_CHALLENGES, array() );
		if ( ! is_array( $challenges ) ) {
			$challenges = array();
		}
		$challenges[ $token ] = sanitize_text_field( $key_authorization );
		update_option( self::OPT_CHALLENGES, $challenges, false );

		$dir = ABSPATH . '.well-known/acme-challenge';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$fs = self::get_filesystem();
		if ( $fs && is_dir( $dir ) && $fs->is_writable( $dir ) ) {
			$fs->put_contents( $dir . '/' . $token, $key_authorization, FS_CHMOD_FILE );
		}
	}

	/**
	 * Clean up challenge files after verification completes.
	 */
	public static function clear_challenges() {
		$challenges = get_option( self::OPT_CHALLENGES, array() );
		if ( is_array( $challenges ) ) {
			$dir = ABSPATH . '.well-known/acme-challenge';
			foreach ( array_keys( $challenges ) as $token ) {
				$file = $dir . '/' . preg_replace( '/[^a-zA-Z0-9_\-]/', '', $token );
				if ( file_exists( $file ) ) {
					wp_delete_file( $file );
				}
			}
		}
		delete_option( self::OPT_CHALLENGES );
	}

	/**
	 * Issue a free 90-day Let's Encrypt SSL certificate for the site domain and install it into cPanel via UAPI `SSL::install_ssl`.
	 *
	 * @param CAM_UAPI_Client $uapi_client Configured UAPI client.
	 * @param bool            $include_www Whether to also include www.<domain> in the certificate SANs.
	 * @return array|WP_Error
	 */
	public function issue_and_install_letsencrypt( $uapi_client, $include_www = true ) {
		if ( ! function_exists( 'openssl_pkey_new' ) || ! function_exists( 'openssl_csr_new' ) ) {
			return new WP_Error( 'cam_no_openssl', __( 'PHP OpenSSL extension is required to generate Let\'s Encrypt certificates.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		$site_domain = CAM_SSL_Service::get_site_domain();
		$bare_domain = preg_replace( '/^www\./i', '', $site_domain );
		$domains     = array( $bare_domain );

		if ( $include_www ) {
			$www_domain = 'www.' . $bare_domain;
			// Only add www if it resolves via DNS/HTTP
			$probe_www = wp_remote_head( 'http://' . $www_domain, array( 'timeout' => 5, 'redirection' => 0 ) );
			if ( ! is_wp_error( $probe_www ) ) {
				$domains[] = $www_domain;
			}
		}

		CAM_SSL_Service::log( 'info', 'Starting Direct Let\'s Encrypt ACME v2 issuance for: ' . implode( ', ', $domains ) );

		// 1. Load ACME Directory
		$dir = $this->get_directory();
		if ( is_wp_error( $dir ) ) {
			return $dir;
		}

		// 2. Ensure ACME Account Key & Registration
		$acct = $this->ensure_account();
		if ( is_wp_error( $acct ) ) {
			return $acct;
		}

		// 3. Create New Order
		$identifiers = array();
		foreach ( $domains as $d ) {
			$identifiers[] = array(
				'type'  => 'dns',
				'value' => $d,
			);
		}

		$order_res = $this->signed_post( $dir['newOrder'], array( 'identifiers' => $identifiers ) );
		if ( is_wp_error( $order_res ) ) {
			return $order_res;
		}

		$order_url = $order_res['location'];
		$order     = $order_res['body'];

		if ( empty( $order['authorizations'] ) || ! is_array( $order['authorizations'] ) ) {
			return new WP_Error( 'cam_acme_order_failed', __( 'Let\'s Encrypt did not return authorization URLs.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		// 4. Process HTTP-01 Challenges for each domain
		$jwk_thumbprint = $this->get_jwk_thumbprint();

		foreach ( $order['authorizations'] as $auth_url ) {
			$auth_res = $this->signed_post( $auth_url, null ); // POST-as-GET
			if ( is_wp_error( $auth_res ) ) {
				self::clear_challenges();
				return $auth_res;
			}

			$auth_data = $auth_res['body'];
			if ( isset( $auth_data['status'] ) && 'valid' === $auth_data['status'] ) {
				continue;
			}

			$http_challenge = null;
			if ( ! empty( $auth_data['challenges'] ) && is_array( $auth_data['challenges'] ) ) {
				foreach ( $auth_data['challenges'] as $ch ) {
					if ( isset( $ch['type'] ) && 'http-01' === $ch['type'] ) {
						$http_challenge = $ch;
						break;
					}
				}
			}

			if ( ! $http_challenge ) {
				self::clear_challenges();
				return new WP_Error( 'cam_no_http01', __( 'No HTTP-01 challenge offered by Let\'s Encrypt.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
			}

			$token    = $http_challenge['token'];
			$key_auth = $token . '.' . $jwk_thumbprint;

			self::store_challenge( $token, $key_auth );

			// Tell ACME server we are ready for challenge verification
			$trigger_res = $this->signed_post( $http_challenge['url'], new stdClass() );
			if ( is_wp_error( $trigger_res ) ) {
				self::clear_challenges();
				return $trigger_res;
			}

			// Poll authorization status up to 10 times
			$verified = false;
			for ( $i = 0; $i < 10; $i++ ) {
				sleep( 2 );
				$poll = $this->signed_post( $auth_url, null );
				if ( is_wp_error( $poll ) ) {
					continue;
				}
				$st = isset( $poll['body']['status'] ) ? $poll['body']['status'] : '';
				if ( 'valid' === $st ) {
					$verified = true;
					break;
				}
				if ( 'invalid' === $st ) {
					$err_detail = isset( $poll['body']['challenges'][0]['error']['detail'] )
						? $poll['body']['challenges'][0]['error']['detail']
						: __( 'HTTP-01 challenge validation failed.', 'autossl-lets-encrypt-manager-for-cpanel' );
					self::clear_challenges();
					return new WP_Error( 'cam_dcv_invalid', 'Let\'s Encrypt DCV Error: ' . $err_detail );
				}
			}

			if ( ! $verified ) {
				self::clear_challenges();
				return new WP_Error( 'cam_dcv_timeout', __( 'Let\'s Encrypt domain validation timed out.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
			}
		}

		self::clear_challenges();

		// 5. Generate Domain Private Key & CSR (with SANs)
		$cert_keys = self::generate_domain_key_and_csr( $bare_domain, $domains );
		if ( is_wp_error( $cert_keys ) ) {
			return $cert_keys;
		}

		// 6. Finalize ACME Order with CSR
		$csr_der = self::pem_to_der( $cert_keys['csr_pem'] );
		$fin_res = $this->signed_post(
			$order['finalize'],
			array(
				'csr' => self::base64url_encode( $csr_der ),
			)
		);
		if ( is_wp_error( $fin_res ) ) {
			return $fin_res;
		}

		// Poll order until certificate URL is ready
		$cert_url = isset( $fin_res['body']['certificate'] ) ? $fin_res['body']['certificate'] : '';
		if ( empty( $cert_url ) && ! empty( $order_url ) ) {
			for ( $i = 0; $i < 10; $i++ ) {
				sleep( 2 );
				$ord_poll = $this->signed_post( $order_url, null );
				if ( ! is_wp_error( $ord_poll ) && ! empty( $ord_poll['body']['certificate'] ) ) {
					$cert_url = $ord_poll['body']['certificate'];
					break;
				}
			}
		}

		if ( empty( $cert_url ) ) {
			return new WP_Error( 'cam_no_cert_url', __( 'Let\'s Encrypt finalized the order but did not return a certificate download URL.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		// 7. Download Issued Certificate Chain (Leaf CRT + Intermediate CA Bundle)
		$cert_dl = $this->signed_post( $cert_url, null, true );
		if ( is_wp_error( $cert_dl ) ) {
			return $cert_dl;
		}

		$fullchain_pem = trim( $cert_dl['raw_body'] );
		$split         = self::split_fullchain_pem( $fullchain_pem );

		if ( empty( $split['cert'] ) ) {
			return new WP_Error( 'cam_bad_cert_pem', __( 'Could not parse PEM certificate returned by Let\'s Encrypt.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		CAM_SSL_Service::log( 'success', 'Let\'s Encrypt certificate issued! Installing into cPanel via UAPI SSL::install_ssl...' );

		// 8. Install directly into cPanel via UAPI `SSL::install_ssl`
		$install_params = array(
			'domain' => $bare_domain,
			'cert'   => $split['cert'],
			'key'    => $cert_keys['private_key_pem'],
		);
		if ( ! empty( $split['cabundle'] ) ) {
			$install_params['cabundle'] = $split['cabundle'];
		}

		$install_res = $uapi_client->call( 'SSL', 'install_ssl', $install_params, 'POST' );
		if ( is_wp_error( $install_res ) ) {
			CAM_SSL_Service::log( 'error', 'cPanel SSL::install_ssl failed: ' . $install_res->get_error_message() );
			return $install_res;
		}

		CAM_SSL_Service::log( 'success', 'Installed new 90-day Let\'s Encrypt SSL certificate into cPanel for ' . $bare_domain . '!' );

		return array(
			'domains'      => $domains,
			'cert_pem'     => $split['cert'],
			'cabundle_pem' => $split['cabundle'],
			'uapi_result'  => $install_res,
		);
	}

	/**
	 * Generate a 2048-bit RSA Private Key and CSR with Subject Alternative Names (SANs).
	 *
	 * @param string $primary_domain Primary domain.
	 * @param array  $san_domains    All SAN domains.
	 * @return array|WP_Error        [ 'private_key_pem', 'csr_pem' ]
	 */
	public static function generate_domain_key_and_csr( $primary_domain, $san_domains = array() ) {
		if ( empty( $san_domains ) ) {
			$san_domains = array( $primary_domain );
		}

		$san_list = array();
		foreach ( $san_domains as $d ) {
			$san_list[] = 'DNS:' . trim( $d );
		}
		$san_str = implode( ', ', $san_list );

		// Create temporary OpenSSL config with v3_req SubjectAltName
		$tmp_cnf = wp_tempnam( 'cam_openssl.cnf' );
		$cnf     = "[req]\ndistinguished_name = req_distinguished_name\nreq_extensions = v3_req\n[req_distinguished_name]\n[v3_req]\nsubjectAltName = {$san_str}\n";
		$fs      = self::get_filesystem();
		if ( $fs ) {
			$fs->put_contents( $tmp_cnf, $cnf, FS_CHMOD_FILE );
		}

		$key_cfg = array(
			'private_key_bits' => 2048,
			'private_key_type' => OPENSSL_KEYTYPE_RSA,
			'config'           => $tmp_cnf,
		);

		$priv_key = @openssl_pkey_new( $key_cfg ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! $priv_key ) {
			// Fallback without custom config path if system openssl.cnf is strict
			unset( $key_cfg['config'] );
			$priv_key = @openssl_pkey_new( $key_cfg ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		if ( ! $priv_key ) {
			wp_delete_file( $tmp_cnf );
			return new WP_Error( 'cam_pkey_failed', __( 'OpenSSL failed to generate 2048-bit RSA private key.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		$priv_pem = '';
		@openssl_pkey_export( $priv_key, $priv_pem, null, array( 'config' => $tmp_cnf ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( empty( $priv_pem ) ) {
			@openssl_pkey_export( $priv_key, $priv_pem ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$dn  = array( 'commonName' => $primary_domain );
		$csr = @openssl_csr_new( $dn, $priv_key, array( 'digest_alg' => 'sha256', 'req_extensions' => 'v3_req', 'config' => $tmp_cnf ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! $csr ) {
			$csr = @openssl_csr_new( $dn, $priv_key, array( 'digest_alg' => 'sha256' ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		wp_delete_file( $tmp_cnf );

		if ( ! $csr ) {
			return new WP_Error( 'cam_csr_failed', __( 'OpenSSL failed to generate CSR for domain.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		$csr_pem = '';
		openssl_csr_export( $csr, $csr_pem );

		return array(
			'private_key_pem' => $priv_pem,
			'csr_pem'         => $csr_pem,
		);
	}

	/**
	 * Fetch Let's Encrypt ACME v2 directory endpoints.
	 *
	 * @return array|WP_Error
	 */
	private function get_directory() {
		if ( null !== $this->directory ) {
			return $this->directory;
		}

		$res = wp_remote_get( self::DIRECTORY_URL, array( 'timeout' => 20 ) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$json = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $json ) || empty( $json['newAccount'] ) ) {
			return new WP_Error( 'cam_acme_dir_error', __( 'Unable to fetch Let\'s Encrypt ACME v2 directory.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		$this->directory = $json;
		return $this->directory;
	}

	/**
	 * Fetch a fresh Replay-Nonce from Let's Encrypt.
	 *
	 * @return string|WP_Error
	 */
	private function get_nonce() {
		if ( ! empty( $this->nonce ) ) {
			$n           = $this->nonce;
			$this->nonce = '';
			return $n;
		}

		$dir = $this->get_directory();
		if ( is_wp_error( $dir ) ) {
			return $dir;
		}

		$res = wp_remote_head( $dir['newNonce'], array( 'timeout' => 15 ) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$nonce = wp_remote_retrieve_header( $res, 'replay-nonce' );
		if ( empty( $nonce ) ) {
			return new WP_Error( 'cam_acme_nonce_error', __( 'Could not retrieve Replay-Nonce from Let\'s Encrypt.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
		}

		return $nonce;
	}

	/**
	 * Ensure an ACME v2 account key exists and is registered with Let's Encrypt.
	 *
	 * @return true|WP_Error
	 */
	private function ensure_account() {
		$saved = get_option( self::OPT_ACCOUNT, array() );
		if ( ! empty( $saved['key_enc'] ) ) {
			$this->account_key_pem = CAM_Crypto::decrypt( $saved['key_enc'] );
		}

		if ( empty( $this->account_key_pem ) ) {
			$res_key = @openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

			if ( ! $res_key ) {
				return new WP_Error( 'cam_acct_key_error', __( 'Failed to generate ACME account key.', 'autossl-lets-encrypt-manager-for-cpanel' ) );
			}
			openssl_pkey_export( $res_key, $this->account_key_pem );
		}

		$dir   = $this->get_directory();
		$email = get_option( 'admin_email' );
		$body  = array(
			'termsOfServiceAgreed' => true,
			'contact'              => array( 'mailto:' . $email ),
		);

		$reg = $this->signed_post( $dir['newAccount'], $body, false, true );
		if ( is_wp_error( $reg ) ) {
			return $reg;
		}

		$this->account_kid = $reg['location'];
		update_option(
			self::OPT_ACCOUNT,
			array(
				'key_enc' => CAM_Crypto::encrypt( $this->account_key_pem ),
				'kid'     => $this->account_kid,
			),
			false
		);

		return true;
	}

	/**
	 * Extract RSA public key JWK components (e, n).
	 *
	 * @return array
	 */
	private function get_account_jwk() {
		$pkey    = openssl_pkey_get_private( $this->account_key_pem );
		$details = openssl_pkey_get_details( $pkey );
		return array(
			'e'   => self::base64url_encode( $details['rsa']['e'] ),
			'kty' => 'RSA',
			'n'   => self::base64url_encode( $details['rsa']['n'] ),
		);
	}

	/**
	 * Compute RFC 7638 JWK Thumbprint for HTTP-01 Key Authorization.
	 *
	 * @return string
	 */
	private function get_jwk_thumbprint() {
		$jwk  = $this->get_account_jwk();
		$json = wp_json_encode( $jwk );
		return self::base64url_encode( hash( 'sha256', $json, true ) );
	}

	/**
	 * Send a JWS-signed ACME v2 request.
	 *
	 * @param string          $url         ACME endpoint URL.
	 * @param array|null|object $payload   Payload array, stdClass for '{}', or null for POST-as-GET.
	 * @param bool            $raw_return  Whether to return raw PEM body instead of JSON.
	 * @param bool            $use_jwk     True for newAccount registration, false to use Kid.
	 * @return array|WP_Error
	 */
	private function signed_post( $url, $payload, $raw_return = false, $use_jwk = false ) {
		$nonce = $this->get_nonce();
		if ( is_wp_error( $nonce ) ) {
			return $nonce;
		}

		$protected = array(
			'alg'   => 'RS256',
			'nonce' => $nonce,
			'url'   => $url,
		);

		if ( $use_jwk || empty( $this->account_kid ) ) {
			$protected['jwk'] = $this->get_account_jwk();
		} else {
			$protected['kid'] = $this->account_kid;
		}

		$protected64 = self::base64url_encode( wp_json_encode( $protected, JSON_UNESCAPED_SLASHES ) );
		if ( null === $payload ) {
			$payload64 = '';
		} else {
			$payload64 = self::base64url_encode( wp_json_encode( $payload, JSON_UNESCAPED_SLASHES ) );
		}

		$signing_input = $protected64 . '.' . $payload64;
		$pkey          = openssl_pkey_get_private( $this->account_key_pem );
		$signature     = '';
		openssl_sign( $signing_input, $signature, $pkey, OPENSSL_ALGO_SHA256 );

		$jws = array(
			'protected' => $protected64,
			'payload'   => $payload64,
			'signature' => self::base64url_encode( $signature ),
		);

		$res = wp_remote_post(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type' => 'application/jose+json',
				),
				'body'    => wp_json_encode( $jws ),
			)
		);

		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$new_nonce = wp_remote_retrieve_header( $res, 'replay-nonce' );
		if ( ! empty( $new_nonce ) ) {
			$this->nonce = $new_nonce;
		}

		$code     = (int) wp_remote_retrieve_response_code( $res );
		$raw_body = wp_remote_retrieve_body( $res );
		$location = wp_remote_retrieve_header( $res, 'location' );

		if ( $code >= 400 ) {
			$err_json = json_decode( $raw_body, true );
			$detail   = isset( $err_json['detail'] ) ? $err_json['detail'] : 'HTTP ' . $code;
			return new WP_Error( 'cam_acme_http_error', 'Let\'s Encrypt Error: ' . $detail );
		}

		return array(
			'code'     => $code,
			'location' => $location,
			'raw_body' => $raw_body,
			'body'     => $raw_return ? null : json_decode( $raw_body, true ),
		);
	}

	/**
	 * Convert PEM CSR to raw binary DER.
	 *
	 * @param string $pem PEM string.
	 * @return string
	 */
	private static function pem_to_der( $pem ) {
		$lines = explode( "\n", trim( $pem ) );
		$b64   = '';
		foreach ( $lines as $line ) {
			if ( strpos( $line, '-----' ) === false ) {
				$b64 .= trim( $line );
			}
		}
		return base64_decode( $b64 );
	}

	/**
	 * Split Let's Encrypt fullchain PEM into leaf CRT and intermediate CA Bundle.
	 *
	 * @param string $fullchain Full PEM chain.
	 * @return array [ 'cert' => string, 'cabundle' => string ]
	 */
	private static function split_fullchain_pem( $fullchain ) {
		if ( ! preg_match_all( '/(-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----)/s', $fullchain, $matches ) ) {
			return array(
				'cert'     => '',
				'cabundle' => '',
			);
		}
		$certs    = $matches[1];
		$leaf     = array_shift( $certs );
		$cabundle = implode( "\n\n", $certs );
		return array(
			'cert'     => trim( $leaf ),
			'cabundle' => trim( $cabundle ),
		);
	}

	/**
	 * Base64URL encode helper.
	 *
	 * @param string $data Binary or string data.
	 * @return string
	 */
	private static function base64url_encode( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}
}
