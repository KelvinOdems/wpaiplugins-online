<?php
/**
 * cPanel UAPI HTTP Client over port 2083 using cPanel API Tokens.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CAM_UAPI_Client {

	/**
	 * cPanel hostname.
	 *
	 * @var string
	 */
	private $host;

	/**
	 * cPanel port (default 2083).
	 *
	 * @var int
	 */
	private $port;

	/**
	 * cPanel account username.
	 *
	 * @var string
	 */
	private $username;

	/**
	 * cPanel API Token.
	 *
	 * @var string
	 */
	private $api_token;

	/**
	 * Verify SSL certificate when connecting to cPanel port 2083.
	 *
	 * @var bool
	 */
	private $verify_ssl;

	/**
	 * Construct UAPI client from stored settings or custom args.
	 *
	 * @param array $config Optional override config.
	 */
	public function __construct( $config = array() ) {
		$saved = get_option( CAM_OPTION_SETTINGS, array() );
		$cfg   = wp_parse_args( $config, $saved );

		$this->host       = ! empty( $cfg['cpanel_host'] ) ? $this->clean_host( $cfg['cpanel_host'] ) : $this->detect_default_host();
		$this->port       = ! empty( $cfg['cpanel_port'] ) ? absint( $cfg['cpanel_port'] ) : 2083;
		$this->username   = ! empty( $cfg['cpanel_user'] ) ? sanitize_text_field( $cfg['cpanel_user'] ) : '';
		$this->verify_ssl = isset( $cfg['verify_ssl'] ) ? (bool) $cfg['verify_ssl'] : false;

		if ( ! empty( $config['api_token_plain'] ) ) {
			$this->api_token = trim( $config['api_token_plain'] );
		} elseif ( ! empty( $cfg['api_token_enc'] ) ) {
			$this->api_token = CAM_Crypto::decrypt( $cfg['api_token_enc'] );
		} else {
			$this->api_token = '';
		}
	}

	/**
	 * Clean hostname string.
	 *
	 * @param string $host Raw host input.
	 * @return string
	 */
	private function clean_host( $host ) {
		$host = trim( $host );
		$host = preg_replace( '#^https?://#i', '', $host );
		$host = preg_replace( '#/.*$#', '', $host );
		$host = preg_replace( '#:\d+$#', '', $host );
		return sanitize_text_field( $host );
	}

	/**
	 * Detect current site domain as default cPanel host.
	 *
	 * @return string
	 */
	public function detect_default_host() {
		$parsed = wp_parse_url( home_url() );
		return ! empty( $parsed['host'] ) ? $parsed['host'] : 'localhost';
	}

	/**
	 * Check if credentials are configured.
	 *
	 * @return bool
	 */
	public function is_configured() {
		return ! empty( $this->host ) && ! empty( $this->username ) && ! empty( $this->api_token );
	}

	/**
	 * Execute a cPanel UAPI call.
	 *
	 * @param string $module   UAPI Module name (e.g., 'SSL').
	 * @param string $function UAPI Function name (e.g., 'start_autossl_check').
	 * @param array  $params   Query or POST parameters.
	 * @param string $method   HTTP method ('GET' or 'POST').
	 * @return array|WP_Error  Normalized UAPI response array or WP_Error.
	 */
	public function call( $module, $function, $params = array(), $method = 'GET' ) {
		if ( ! $this->is_configured() ) {
			return new WP_Error(
				'cam_not_configured',
				__( 'cPanel host, username, and API token are required before calling UAPI.', 'autossl-lets-encrypt-manager-for-cpanel' )
			);
		}

		$module   = preg_replace( '/[^a-zA-Z0-9_]/', '', $module );
		$function = preg_replace( '/[^a-zA-Z0-9_]/', '', $function );
		$url      = sprintf( 'https://%s:%d/execute/%s/%s', $this->host, $this->port, $module, $function );

		$args = array(
			'method'    => strtoupper( $method ),
			'timeout'   => 30,
			'sslverify' => $this->verify_ssl,
			'headers'   => array(
				'Authorization' => sprintf( 'cpanel %s:%s', $this->username, $this->api_token ),
				'Accept'        => 'application/json',
			),
		);

		if ( 'GET' === $args['method'] && ! empty( $params ) ) {
			$url = add_query_arg( $params, $url );
		} elseif ( 'POST' === $args['method'] && ! empty( $params ) ) {
			$args['body'] = $params;
		}

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'cam_http_error',
				sprintf(
					/* translators: %s: error message */
					__( 'Failed to connect to cPanel UAPI (%s). Verify cPanel host and that port 2083 outbound is open.', 'autossl-lets-encrypt-manager-for-cpanel' ),
					$response->get_error_message()
				)
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( 401 === $code || 403 === $code ) {
			return new WP_Error(
				'cam_auth_failed',
				__( 'cPanel authentication failed (HTTP 401/403). Please verify your cPanel Username and API Token.', 'autossl-lets-encrypt-manager-for-cpanel' )
			);
		}

		$json = json_decode( $body, true );
		if ( ! is_array( $json ) ) {
			return new WP_Error(
				'cam_invalid_json',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Unexpected non-JSON response from cPanel UAPI (HTTP %d).', 'autossl-lets-encrypt-manager-for-cpanel' ),
					$code
				)
			);
		}

		// UAPI returns status = 1 on success, status = 0 on error with errors[] array.
		if ( isset( $json['status'] ) && 0 === (int) $json['status'] ) {
			$err_msgs = ! empty( $json['errors'] ) && is_array( $json['errors'] )
				? implode( ' | ', $json['errors'] )
				: __( 'Unknown cPanel UAPI error.', 'autossl-lets-encrypt-manager-for-cpanel' );
			return new WP_Error( 'cam_uapi_error', $err_msgs, $json );
		}

		return array(
			'status'   => isset( $json['status'] ) ? (int) $json['status'] : 1,
			'data'     => isset( $json['data'] ) ? $json['data'] : null,
			'messages' => isset( $json['messages'] ) && is_array( $json['messages'] ) ? $json['messages'] : array(),
			'warnings' => isset( $json['warnings'] ) && is_array( $json['warnings'] ) ? $json['warnings'] : array(),
			'raw'      => $json,
		);
	}
}
