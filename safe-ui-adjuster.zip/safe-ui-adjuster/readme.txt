=== Safe UI Adjuster ===
Contributors: kelvinodems
Tags: ui, ai, css, customizer, gutenberg
Requires at least: 5.8
Tested up to: 7.1
Stable tag: 1.1.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Conversational AI assistant to adjust your site's frontend UI, CSS/layout, DOM banners/text, and Block Editor/Role permissions with 1-click rollback.

== Description ==

**Safe UI Adjuster** provides a conversational chat interface and point-and-click element selector to adjust your WordPress frontend styles, layout, announcement banners, and role-based Block Editor/Admin UI without modifying theme files or database post content.

= Key Features =
* **Floating Frontend Chat Drawer + Point-and-Click Element Selector (`⊕`):** Click any element on your live site and ask the assistant to restyle, hide, or update it with zero-reload preview.
* **Split-Screen AI Chat Studio in WP Admin:** Full chat workspace on the left with a responsive live preview (Desktop / Tablet / Mobile), Active Rules Inspector, and Snapshot History on the right.
* **Built-in Local Smart Command Parser + Multi-Provider BYOK AI:** Works out-of-the-box with zero external API calls using the built-in Local Smart Command Engine, or optionally connect your own API key (BYOK) for Google Gemini, OpenAI, or Anthropic Claude.
* **4-Layer Zero-Breakage Safety Net:** Includes Admin-Only Preview Mode staging, balanced-brace CSS syntax validation, 20-turn snapshot history with 1-click Undo on every chat message, and the `?wsua_safe_mode=1` emergency bypass URL switch.

== External Services ==

By default, this plugin runs 100% locally on your WordPress server using its built-in Local Smart Command Parser and makes **no** external requests.

If you explicitly enter your own API key (BYOK) in **WP Safe UI AI → AI Providers (BYOK)**, the plugin connects to your chosen provider when you send a chat message:

1. **Google Gemini API (`https://generativelanguage.googleapis.com/v1beta/models/...`)**
   * **Data Sent:** Your chat prompt, active theme name, and the CSS selector/tag of any element you explicitly selected with the point-and-click picker.
   * **Terms & Privacy:** [Google Gemini API Terms](https://ai.google.dev/gemini-api/terms) | [Google Privacy Policy](https://policies.google.com/privacy).

2. **OpenAI API (`https://api.openai.com/v1/chat/completions`)**
   * **Data Sent:** Your chat prompt, active theme name, and selected element CSS selector/tag.
   * **Terms & Privacy:** [OpenAI Terms of Use](https://openai.com/policies/terms-of-use/) | [OpenAI Privacy Policy](https://openai.com/policies/privacy-policy/).

3. **Anthropic Claude API (`https://api.anthropic.com/v1/messages`)**
   * **Data Sent:** Your chat prompt, active theme name, and selected element CSS selector/tag.
   * **Terms & Privacy:** [Anthropic Terms of Service](https://www.anthropic.com/legal/commercial-terms) | [Anthropic Privacy Policy](https://www.anthropic.com/legal/privacy).

== Installation ==

1. Upload the `wp-safe-ui-adjuster` folder to `/wp-content/plugins/` or upload `wp-safe-ui-adjuster.zip` via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Open **WP Safe UI AI** in your admin sidebar or visit your frontend while logged in as an Administrator to use the floating chat drawer.

== Changelog ==

= 1.1.1 =
* Added `readme.txt` with External Services disclosure, enqueued virtual styles via `wp_add_inline_style`, and updated display name for WordPress.org trademark compliance.

= 1.1.0 =
* Redesigned Admin Studio and Floating Chat Drawer with a modern light UI and inline SVG icons.

= 1.0.0 =
* Initial release.
