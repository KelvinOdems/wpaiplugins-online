(function ($) {
	'use strict';

	if (typeof WSUA_StudioConfig === 'undefined') {
		return;
	}

	var selectedMeta = null;
	var $messages = $('#wsua-studio-messages');
	var $iframe = $('#wsua-preview-iframe');

	function escapeHtml(str) {
		return $('<div>').text(str || '').html();
	}

	function renderChatTurn(turn) {
		if (!turn) return;
		var selBadge = turn.selected_element
			? '<div style="font-size:11px;color:#93c5fd;font-family:monospace;margin-bottom:4px;">@selected: ' + escapeHtml(turn.selected_element) + '</div>'
			: '';

		var userHtml = '<div class="wsua-chat-card is-user">' + selBadge + escapeHtml(turn.user_prompt) + '</div>';
		$messages.append(userHtml);

		var actionsHtml = '';
		if (Array.isArray(turn.actions_summary) && turn.actions_summary.length) {
			actionsHtml = '<div class="wsua-card-actions">';
			turn.actions_summary.forEach(function (a) {
				actionsHtml += '<div>✓ ' + escapeHtml(a) + '</div>';
			});
			actionsHtml += '</div>';
		}

		var undoHtml = turn.snapshot_id
			? '<button type="button" class="wsua-card-undo" data-snap="' + escapeHtml(turn.snapshot_id) + '">↺ Undo this turn</button>'
			: '';

		var assistantHtml = '<div class="wsua-chat-card is-assistant">' +
			'<div>' + escapeHtml(turn.assistant_reply) + '</div>' +
			actionsHtml +
			undoHtml +
			'</div>';

		$messages.append(assistantHtml);
		$messages.scrollTop($messages[0].scrollHeight);
	}

	function renderSnapshotsList(snapshots) {
		var $list = $('#wsua-snapshots-list');
		if (!Array.isArray(snapshots) || !snapshots.length) {
			$list.html('<p class="wsua-muted">No snapshots recorded yet.</p>');
			return;
		}
		var html = '';
		snapshots.forEach(function (s) {
			html += '<div class="wsua-list-item">' +
				'<div><strong>' + escapeHtml(s.label) + '</strong> <span style="color:#64748b;font-size:12px;">(' + escapeHtml(s.created_at) + ')</span></div>' +
				'<button type="button" class="button button-secondary wsua-card-undo" data-snap="' + escapeHtml(s.id) + '">↺ Restore Snapshot</button>' +
				'</div>';
		});
		$list.html(html);
	}

	function renderInspectorLists(state, compiledCss) {
		if (typeof compiledCss === 'string') {
			$('#wsua-compiled-css-box').text(compiledCss);
		}
		if (!state) return;

		$('#wsua-role-rules-box').text(JSON.stringify(state.role_ui_rules || {}, null, 2));

		var patches = Array.isArray(state.dom_patches) ? state.dom_patches : [];
		var $domList = $('#wsua-dom-patches-list');
		if (!patches.length) {
			$domList.html('<p class="wsua-muted">No active DOM content patches.</p>');
		} else {
			var pHtml = '';
			patches.forEach(function (p) {
				pHtml += '<div class="wsua-list-item">' +
					'<div><code>' + escapeHtml(p.type) + '</code> on <code>' + escapeHtml(p.selector) + '</code> → ' + escapeHtml(p.content) + '</div>' +
					'<button type="button" class="button button-link-delete wsua-del-rule" data-kind="dom_patch" data-id="' + escapeHtml(p.id) + '">Remove</button>' +
					'</div>';
			});
			$domList.html(pHtml);
		}
	}

	function broadcastLiveUpdateToIframe(compiledCss, domPatches) {
		var frameWin = $iframe[0] && $iframe[0].contentWindow;
		if (frameWin) {
			frameWin.postMessage({
				type: 'WSUA_LIVE_UPDATE',
				compiledCss: compiledCss,
				domPatches: domPatches
			}, '*');
		}
	}

	// Initialize existing chat history & snapshots
	if (Array.isArray(WSUA_StudioConfig.history) && WSUA_StudioConfig.history.length) {
		WSUA_StudioConfig.history.forEach(renderChatTurn);
	} else {
		renderChatTurn({
			user_prompt: 'Welcome to WP Safe UI Studio!',
			assistant_reply: 'Describe any layout, CSS, content banner, or Gutenberg/Role UI adjustment here. You can also click "⊕ Pick Element" and click any element inside the live preview on the right!'
		});
	}

	renderSnapshotsList(WSUA_StudioConfig.snapshots);
	renderInspectorLists(WSUA_StudioConfig.state);

	// Listen for element picked inside the preview iframe
	window.addEventListener('message', function (event) {
		if (!event.data || event.data.type !== 'WSUA_ELEMENT_PICKED') return;
		selectedMeta = event.data.payload;
		$('#wsua-studio-pick-btn').removeClass('is-picking');
		$('#wsua-studio-selected-code').text(selectedMeta.selector);
		$('#wsua-studio-selected-bar').show();
		$('#wsua-studio-input').focus();
	});

	$('#wsua-studio-pick-btn').on('click', function () {
		$(this).toggleClass('is-picking');
		var frameWin = $iframe[0] && $iframe[0].contentWindow;
		if (frameWin) {
			frameWin.postMessage({ type: 'WSUA_START_PICKER' }, '*');
		}
	});

	$('#wsua-studio-clear-sel').on('click', function () {
		selectedMeta = null;
		$('#wsua-studio-selected-bar').hide();
	});

	// Prompt chips
	$('.wsua-studio-chip').on('click', function () {
		$('#wsua-studio-input').val($(this).data('prompt'));
		$('#wsua-studio-chat-form').trigger('submit');
	});

	// Send Chat Form
	$('#wsua-studio-chat-form').on('submit', function (e) {
		e.preventDefault();
		var prompt = $('#wsua-studio-input').val().trim();
		if (!prompt) return;

		var $btn = $('#wsua-studio-send');
		$('#wsua-studio-input').val('');
		$btn.prop('disabled', true).text('Thinking...');

		$.post(WSUA_StudioConfig.ajaxUrl, {
			action: 'wsua_send_chat',
			nonce: WSUA_StudioConfig.nonce,
			prompt: prompt,
			selected_element: selectedMeta ? JSON.stringify(selectedMeta) : ''
		}, function (res) {
			$btn.prop('disabled', false).text('Send ↑');
			if (res.success && res.data) {
				renderChatTurn(res.data.turn);
				renderSnapshotsList(res.data.snapshots);
				renderInspectorLists(res.data.state, res.data.compiled_css);
				broadcastLiveUpdateToIframe(res.data.compiled_css, res.data.dom_patches);
			}
		}).fail(function () {
			$btn.prop('disabled', false).text('Send ↑');
		});
	});

	// 1-Click Undo / Restore Snapshot
	$(document).on('click', '.wsua-card-undo', function () {
		var $btn = $(this);
		var snapId = $btn.data('snap');
		$btn.prop('disabled', true).text('Restoring...');

		$.post(WSUA_StudioConfig.ajaxUrl, {
			action: 'wsua_undo_snapshot',
			nonce: WSUA_StudioConfig.nonce,
			snapshot_id: snapId
		}, function (res) {
			if (res.success && res.data) {
				$btn.text('✓ Restored');
				renderInspectorLists(res.data.state, res.data.compiled_css);
				broadcastLiveUpdateToIframe(res.data.compiled_css, res.data.dom_patches);
			} else {
				$btn.prop('disabled', false).text('↺ Retry Undo');
			}
		});
	});

	// Remove individual DOM patch
	$(document).on('click', '.wsua-del-rule', function () {
		var $btn = $(this);
		$.post(WSUA_StudioConfig.ajaxUrl, {
			action: 'wsua_delete_rule_item',
			nonce: WSUA_StudioConfig.nonce,
			kind: $btn.data('kind'),
			item_id: $btn.data('id')
		}, function (res) {
			if (res.success && res.data) {
				renderInspectorLists(res.data.state, res.data.compiled_css);
				broadcastLiveUpdateToIframe(res.data.compiled_css, res.data.dom_patches);
			}
		});
	});

	// Toggle Preview vs Live Mode
	$('#wsua-studio-mode-btn').on('click', function () {
		var $btn = $(this);
		$.post(WSUA_StudioConfig.ajaxUrl, {
			action: 'wsua_toggle_deploy_mode',
			nonce: WSUA_StudioConfig.nonce
		}, function (res) {
			if (res.success) {
				var isLive = res.data.deploy_mode === 'live';
				$btn.toggleClass('is-live', isLive).toggleClass('is-preview', !isLive);
				$btn.text(isLive ? '● LIVE (All Visitors)' : '◐ PREVIEW (Admins Only)');
			}
		});
	});

	// Tab switching
	$('.wsua-tab').on('click', function () {
		var tab = $(this).data('tab');
		$('.wsua-tab').removeClass('active');
		$(this).addClass('active');
		$('.wsua-tab-panel').removeClass('active');
		$('#wsua-tab-' + tab).addClass('active');
		$('#wsua-viewport-toggles').toggle(tab === 'preview');
	});

	// Viewport width toggles
	$('.wsua-vp-btn').on('click', function () {
		$('.wsua-vp-btn').removeClass('active');
		$(this).addClass('active');
		$iframe.css('width', $(this).data('width'));
	});

	// Save AI Provider Settings
	$('#wsua-ai-settings-form').on('submit', function (e) {
		e.preventDefault();
		var $btn = $('#wsua-save-settings-btn');
		$btn.prop('disabled', true);
		var data = $(this).serialize() + '&action=wsua_save_ai_settings&nonce=' + encodeURIComponent(WSUA_StudioConfig.nonce);

		$.post(WSUA_StudioConfig.ajaxUrl, data, function (res) {
			$btn.prop('disabled', false);
			if (res.success) {
				$('#wsua-settings-status').text(res.data.message);
				$('#wsua-active-provider-pill').text((res.data.provider || '').toUpperCase());
			}
		});
	});
})(jQuery);
