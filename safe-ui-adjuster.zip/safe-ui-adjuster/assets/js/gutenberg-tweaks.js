(function (wp) {
	'use strict';

	if (!wp || typeof WSUA_EditorRules === 'undefined') {
		return;
	}

	wp.domReady(function () {
		// 1. Remove restricted Gutenberg Editor Panels per role
		if (Array.isArray(WSUA_EditorRules.hidePanels) && wp.data && wp.data.dispatch) {
			var editPostDispatch = wp.data.dispatch('core/edit-post') || wp.data.dispatch('core/editor');
			if (editPostDispatch && typeof editPostDispatch.removeEditorPanel === 'function') {
				WSUA_EditorRules.hidePanels.forEach(function (panelName) {
					try {
						editPostDispatch.removeEditorPanel(panelName);
					} catch (e) {}
				});
			}
		}

		// 2. Unregister restricted Gutenberg Block types per role (non-destructive to existing content)
		if (Array.isArray(WSUA_EditorRules.hideBlocks) && wp.blocks && typeof wp.blocks.getBlockTypes === 'function') {
			var allBlocks = wp.blocks.getBlockTypes();
			allBlocks.forEach(function (block) {
				var shouldHide = WSUA_EditorRules.hideBlocks.some(function (rule) {
					return block.name === rule || block.name.indexOf(rule + '/') === 0 || block.category === rule;
				});
				if (shouldHide) {
					try {
						wp.blocks.unregisterBlockType(block.name);
					} catch (e) {}
				}
			});
		}
	});
})(window.wp);
