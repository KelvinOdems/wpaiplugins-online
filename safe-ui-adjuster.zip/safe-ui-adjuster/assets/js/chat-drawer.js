(function () {
	'use strict';

	if (typeof WSUA_DrawerConfig === 'undefined') {
		return;
	}

	var isPicking = false;
	var hoveredEl = null;
	var selectedMeta = null;

	/**
	 * Build a clean, resilient CSS selector for a clicked DOM element.
	 */
	function buildCleanSelector(el) {
		if (!el || el.nodeType !== 1) return '';
		if (el.id && !/^\d/.test(el.id)) {
			return '#' + el.id;
		}

		var parts = [];
		var cur = el;
		var depth = 0;

		while (cur && cur.nodeType === 1 && cur.tagName.toLowerCase() !== 'html' && depth < 3) {
			var tag = cur.tagName.toLowerCase();
			if (cur.id && !/^\d/.test(cur.id)) {
				parts.unshift('#' + cur.id);
				break;
			}
			var clsList = Array.prototype.slice.call(cur.classList || []).filter(function (c) {
				return c.indexOf('wsua-') !== 0 &&
					!/^(active|hover|focus|open|closed|wp-admin|logged-in|admin-bar)$/.test(c);
			});
			if (clsList.length > 0) {
				parts.unshift(tag + '.' + clsList.slice(0, 2).join('.'));
				break;
			}
			parts.unshift(tag);
			cur = cur.parentElement;
			depth++;
		}

		return parts.join(' > ');
	}

	/**
	 * Live-update the virtual CSS stylesheet and DOM patches on the current page without reload.
	 */
	function applyLiveFrontendState(compiledCss, domPatches) {
		var styleTag = document.getElementById('wsua-custom-ui-inline-css') || document.getElementById('wsua-custom-ui');
		if (!styleTag) {
			styleTag = document.createElement('style');
			styleTag.id = 'wsua-custom-ui-inline-css';
			document.head.appendChild(styleTag);
		}
		styleTag.textContent = compiledCss || '';

		if (typeof window.WSUA_ApplyDOMPatches === 'function' && Array.isArray(domPatches)) {
			window.WSUA_ApplyDOMPatches(domPatches);
		}
	}

	/**
	 * Enable or disable Point-and-Click Element Picker mode.
	 */
	function setPickerMode(active) {
		isPicking = active;
		var pickBtn = document.getElementById('wsua-pick-element-btn');
		if (pickBtn) {
			pickBtn.classList.toggle('is-picking', active);
		}
		if (!active && hoveredEl) {
			hoveredEl.classList.remove('wsua-hover-outline');
			hoveredEl = null;
		}
	}

	document.addEventListener('mouseover', function (e) {
		if (!isPicking) return;
		var target = e.target;
		if (target.closest('#wsua-chat-drawer') || target.closest('#wpadminbar')) return;
		if (hoveredEl && hoveredEl !== target) {
			hoveredEl.classList.remove('wsua-hover-outline');
		}
		hoveredEl = target;
		hoveredEl.classList.add('wsua-hover-outline');
	}, true);

	document.addEventListener('click', function (e) {
		if (!isPicking) return;
		var target = e.target;
		if (target.closest('#wsua-chat-drawer') || target.closest('#wpadminbar')) return;

		e.preventDefault();
		e.stopPropagation();

		target.classList.remove('wsua-hover-outline');
		var selector = buildCleanSelector(target);
		selectedMeta = {
			selector: selector,
			tagName: target.tagName.toLowerCase(),
			text: (target.innerText || '').trim().substring(0, 80)
		};

		setPickerMode(false);

		// If running inside Admin Studio preview iframe, postMessage the picked element to parent studio
		if (WSUA_DrawerConfig.isIframe && window.parent) {
			window.parent.postMessage({
				type: 'WSUA_ELEMENT_PICKED',
				payload: selectedMeta
			}, '*');
			return;
		}

		var bar = document.getElementById('wsua-selected-bar');
		var code = document.getElementById('wsua-selected-code');
		var input = document.getElementById('wsua-chat-input');
		if (bar && code) {
			code.textContent = selector;
			bar.style.display = 'flex';
		}
		if (input) {
			input.focus();
		}
	}, true);

	// Listen for commands from parent Admin Studio when inside preview iframe
	window.addEventListener('message', function (event) {
		if (!event.data || !event.data.type) return;
		if (event.data.type === 'WSUA_START_PICKER') {
			setPickerMode(true);
		} else if (event.data.type === 'WSUA_LIVE_UPDATE') {
			applyLiveFrontendState(event.data.compiledCss, event.data.domPatches);
		}
	});

	// If inside preview iframe, stop here (no floating drawer DOM rendered)
	if (WSUA_DrawerConfig.isIframe) {
		return;
	}

	// Floating Drawer UI Setup
	var drawer = document.getElementById('wsua-chat-drawer');
	var launcher = document.getElementById('wsua-launcher-btn');
	var closeBtn = document.getElementById('wsua-close-btn');
	var pickBtn = document.getElementById('wsua-pick-element-btn');
	var clearSelBtn = document.getElementById('wsua-clear-selected');
	var chatForm = document.getElementById('wsua-chat-form');
	var chatInput = document.getElementById('wsua-chat-input');
	var messagesEl = document.getElementById('wsua-messages');
	var modeBtn = document.getElementById('wsua-toggle-mode-btn');
	var launcherMode = document.getElementById('wsua-launcher-mode');

	if (!drawer) return;

	function toggleDrawer(open) {
		var isOpen = typeof open === 'boolean' ? open : drawer.classList.contains('wsua-drawer-closed');
		drawer.classList.toggle('wsua-drawer-open', isOpen);
		drawer.classList.toggle('wsua-drawer-closed', !isOpen);
		if (isOpen && chatInput) {
			chatInput.focus();
		}
	}

	launcher.addEventListener('click', function () { toggleDrawer(true); });
	closeBtn.addEventListener('click', function () { toggleDrawer(false); });

	// Top Admin Bar button integration & Ctrl+Shift+U shortcut
	var adminBarLink = document.querySelector('#wp-admin-bar-wsua-ai-chat-toggle a');
	if (adminBarLink) {
		adminBarLink.addEventListener('click', function (e) {
			e.preventDefault();
			toggleDrawer();
		});
	}

	document.addEventListener('keydown', function (e) {
		if (e.ctrlKey && e.shiftKey && (e.key === 'U' || e.key === 'u')) {
			e.preventDefault();
			toggleDrawer();
		}
	});

	pickBtn.addEventListener('click', function () {
		setPickerMode(!isPicking);
	});

	clearSelBtn.addEventListener('click', function () {
		selectedMeta = null;
		document.getElementById('wsua-selected-bar').style.display = 'none';
	});

	function appendTurnToUI(turn) {
		if (!turn) return;

		// User message
		var uDiv = document.createElement('div');
		uDiv.className = 'wsua-msg wsua-msg-user';
		var uBubble = document.createElement('div');
		uBubble.className = 'wsua-bubble';
		if (turn.selected_element) {
			var pill = document.createElement('div');
			pill.className = 'wsua-sel-pill';
			pill.textContent = '@selected: ' + turn.selected_element;
			uBubble.appendChild(pill);
		}
		var pText = document.createElement('div');
		pText.textContent = turn.user_prompt;
		uBubble.appendChild(pText);
		uDiv.appendChild(uBubble);
		messagesEl.appendChild(uDiv);

		// Assistant message
		var aDiv = document.createElement('div');
		aDiv.className = 'wsua-msg wsua-msg-assistant';
		var aBubble = document.createElement('div');
		aBubble.className = 'wsua-bubble';
		var aText = document.createElement('div');
		aText.textContent = turn.assistant_reply;
		aBubble.appendChild(aText);

		if (Array.isArray(turn.actions_summary) && turn.actions_summary.length) {
			var actList = document.createElement('div');
			actList.className = 'wsua-actions-list';
			turn.actions_summary.forEach(function (act) {
				var row = document.createElement('div');
				row.textContent = act;
				actList.appendChild(row);
			});
			aBubble.appendChild(actList);
		}
		aDiv.appendChild(aBubble);

		if (turn.snapshot_id) {
			var undoBtn = document.createElement('button');
			undoBtn.type = 'button';
			undoBtn.className = 'wsua-undo-btn';
			undoBtn.textContent = '↺ Undo this change';
			undoBtn.addEventListener('click', function () {
				undoSnapshot(turn.snapshot_id, undoBtn);
			});
			aDiv.appendChild(undoBtn);
		}

		messagesEl.appendChild(aDiv);
		messagesEl.scrollTop = messagesEl.scrollHeight;
	}

	function undoSnapshot(snapshotId, btnEl) {
		var orig = btnEl.textContent;
		btnEl.disabled = true;
		btnEl.textContent = 'Reverting...';

		var fd = new FormData();
		fd.append('action', 'wsua_undo_snapshot');
		fd.append('nonce', WSUA_DrawerConfig.nonce);
		fd.append('snapshot_id', snapshotId);

		fetch(WSUA_DrawerConfig.ajaxUrl, {
			method: 'POST',
			body: fd,
			credentials: 'same-origin'
		})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				if (res.success) {
					applyLiveFrontendState(res.data.compiled_css, res.data.dom_patches);
					btnEl.textContent = '✓ Reverted';
				} else {
					btnEl.disabled = false;
					btnEl.textContent = orig;
				}
			});
	}

	// Render initial history or greeting
	if (Array.isArray(WSUA_DrawerConfig.history) && WSUA_DrawerConfig.history.length) {
		WSUA_DrawerConfig.history.forEach(appendTurnToUI);
	} else {
		appendTurnToUI({
			user_prompt: 'How do I adjust my WordPress UI?',
			assistant_reply: 'Click ⊕ to point-and-click any element on your page, or just tell me what to change (e.g. "Make this header sticky", "Change button color to #2563eb", or "Add a top announcement banner"). Every change has a 1-click Undo button!'
		});
	}

	// Quick prompt chips
	document.querySelectorAll('.wsua-chip').forEach(function (chip) {
		chip.addEventListener('click', function () {
			chatInput.value = chip.getAttribute('data-prompt') || '';
			chatForm.dispatchEvent(new Event('submit'));
		});
	});

	// Submit on Enter (Shift+Enter for newline)
	chatInput.addEventListener('keydown', function (e) {
		if (e.key === 'Enter' && !e.shiftKey) {
			e.preventDefault();
			chatForm.dispatchEvent(new Event('submit'));
		}
	});

	// Send Chat Request
	chatForm.addEventListener('submit', function (e) {
		e.preventDefault();
		var prompt = chatInput.value.trim();
		if (!prompt) return;

		var sendBtn = document.getElementById('wsua-send-btn');
		chatInput.value = '';
		sendBtn.disabled = true;
		sendBtn.textContent = '…';

		var fd = new FormData();
		fd.append('action', 'wsua_send_chat');
		fd.append('nonce', WSUA_DrawerConfig.nonce);
		fd.append('prompt', prompt);
		if (selectedMeta) {
			fd.append('selected_element', JSON.stringify(selectedMeta));
		}
		if (WSUA_DrawerConfig.pageContext) {
			fd.append('page_context', JSON.stringify(WSUA_DrawerConfig.pageContext));
		}

		fetch(WSUA_DrawerConfig.ajaxUrl, {
			method: 'POST',
			body: fd,
			credentials: 'same-origin'
		})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				sendBtn.disabled = false;
				sendBtn.textContent = '↑';
				if (res.success && res.data) {
					appendTurnToUI(res.data.turn);
					applyLiveFrontendState(res.data.compiled_css, res.data.dom_patches);
				}
			})
			.catch(function () {
				sendBtn.disabled = false;
				sendBtn.textContent = '↑';
			});
	});

	// Toggle Preview vs Live Mode
	modeBtn.addEventListener('click', function () {
		var fd = new FormData();
		fd.append('action', 'wsua_toggle_deploy_mode');
		fd.append('nonce', WSUA_DrawerConfig.nonce);

		fetch(WSUA_DrawerConfig.ajaxUrl, {
			method: 'POST',
			body: fd,
			credentials: 'same-origin'
		})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				if (res.success) {
					var isLive = res.data.deploy_mode === 'live';
					modeBtn.className = 'wsua-mode-switch ' + (isLive ? 'is-live' : 'is-preview');
					modeBtn.textContent = isLive ? '● Live' : '◐ Preview Only';
					if (launcherMode) {
						launcherMode.className = 'wsua-mode-pill ' + (isLive ? 'wsua-pill-live' : 'wsua-pill-preview');
						launcherMode.textContent = isLive ? 'LIVE' : 'PREVIEW';
					}
				}
			});
	});
})();
