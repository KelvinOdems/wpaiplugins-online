<?php
/**
 * Plugin Name:       Safe UI Adjuster
 * Plugin URI:        https://wpaiplugins.online/plugins/safe-ui-adjuster
 * Description:       Conversational AI assistant to adjust your site's frontend UI, CSS/layout, DOM content/banners, and Block Editor/Role permissions via chat and point-and-click selection—with zero risk of breaking your site.
 * Version:           1.1.2
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Kelvin Odems
 * Author URI:        https://wpaiplugins.online
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       safe-ui-adjuster
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WSUA_VERSION', '1.1.2' );
define( 'WSUA_PLUGIN_FILE', __FILE__ );
define( 'WSUA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSUA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

define( 'WSUA_OPT_SETTINGS', 'wsua_ai_settings' );
define( 'WSUA_OPT_ACTIVE_STATE', 'wsua_active_ui_state' );
define( 'WSUA_OPT_SNAPSHOTS', 'wsua_ui_snapshots' );
define( 'WSUA_OPT_CHAT_HISTORY', 'wsua_chat_history' );

require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-crypto.php';
require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-safety-guard.php';
require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-ai-agent.php';
require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-runtime-engine.php';
require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-editor-roles.php';
require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-frontend-drawer.php';
require_once WSUA_PLUGIN_DIR . 'includes/class-wsua-admin-studio.php';

/**
 * Main Bootstrap Class for WP Safe UI Adjuster.
 */
final class WP_Safe_UI_Adjuster {

	/**
	 * Singleton instance.
	 *
	 * @var WP_Safe_UI_Adjuster|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return WP_Safe_UI_Adjuster
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Initialize plugin modules.
	 */
	private function __construct() {
		WSUA_Safety_Guard::init();
		WSUA_Runtime_Engine::init();
		WSUA_Editor_Roles::init();
		WSUA_Frontend_Drawer::init();
		WSUA_Admin_Studio::init();
	}
}

WP_Safe_UI_Adjuster::instance();
