<?php
/**
 * Uninstall WP Safe UI Adjuster.
 *
 * Removes all virtual UI rules, snapshots, chat history, and encrypted API keys.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wsua_ai_settings' );
delete_option( 'wsua_active_ui_state' );
delete_option( 'wsua_ui_snapshots' );
delete_option( 'wsua_chat_history' );
