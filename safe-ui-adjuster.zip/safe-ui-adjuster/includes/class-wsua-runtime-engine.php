<?php
/**
 * Runtime Overlay Engine:
 * Compiles and injects non-destructive CSS rules, design tokens, and safe DOM content patches
 * on the frontend without modifying theme files or database post content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_Runtime_Engine {

	/**
	 *Initialize frontend hooks.
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_compiled_css' ), 999 );
		add_action( 'wp_footer', array( __CLASS__, 'render_dom_patches_and_safe_banner' ), 999 );
	}

	/**
	 * Compile tokens and CSS rules into a single clean CSS stylesheet string.
	 *
	 * @param array|null $state Optional state array (defaults to active state).
	 * @return string
	 */
	public static function compile_frontend_css( $state = null ) {
		if ( null === $state ) {
			$state = WSUA_Safety_Guard::get_active_state();
		}

		$tokens = isset( $state['tokens'] ) ? $state['tokens'] : array();
		$rules  = isset( $state['css_rules'] ) ? $state['css_rules'] : array();
		$css    = "/* WP Safe UI Adjuster - Virtual Runtime Stylesheet */\n";

		// 1. Design Tokens
		if ( ! empty( $tokens['max_width'] ) ) {
			$mw   = esc_attr( $tokens['max_width'] );
			$css .= ":root { --wp--style--global--content-size: {$mw}; --wp--style--global--wide-size: {$mw}; }\n";
			$css .= ".container, .site-content, .wp-site-blocks > main, .entry-content > .alignwide { max-width: {$mw} !important; margin-left: auto !important; margin-right: auto !important; }\n";
		}

		if ( ! empty( $tokens['bg_color'] ) ) {
			$bg   = esc_attr( $tokens['bg_color'] );
			$css .= "body, .site, .wp-site-blocks { background-color: {$bg} !important; }\n";
		}

		if ( ! empty( $tokens['text_color'] ) ) {
			$tc   = esc_attr( $tokens['text_color'] );
			$css .= "body, p, .entry-content { color: {$tc} !important; }\n";
		}

		if ( ! empty( $tokens['accent_color'] ) ) {
			$ac   = esc_attr( $tokens['accent_color'] );
			$css .= "a { color: {$ac}; }\n";
			$css .= "button, .button, .wp-block-button__link, .wp-element-button, input[type='submit'] { background-color: {$ac} !important; border-color: {$ac} !important; color: #ffffff !important; }\n";
		}

		if ( ! empty( $tokens['base_font_size'] ) ) {
			$fs   = esc_attr( $tokens['base_font_size'] );
			$css .= "body, p, .entry-content { font-size: {$fs} !important; }\n";
		}

		if ( ! empty( $tokens['font_family'] ) ) {
			$ff   = wp_strip_all_tags( $tokens['font_family'] );
			$css .= "body, h1, h2, h3, h4, h5, h6, p, a, button, input { font-family: {$ff} !important; }\n";
		}

		if ( ! empty( $tokens['sticky_header'] ) ) {
			$css .= "header.site-header, #masthead, .wp-site-blocks > header { position: sticky !important; top: 0 !important; z-index: 999 !important; }\n";
		}

		if ( ! empty( $tokens['hide_selectors'] ) && is_array( $tokens['hide_selectors'] ) ) {
			$valid_sels = array_filter( array_map( array( 'WSUA_Safety_Guard', 'sanitize_selector' ), $tokens['hide_selectors'] ) );
			if ( ! empty( $valid_sels ) ) {
				$css .= implode( ', ', $valid_sels ) . " { display: none !important; }\n";
			}
		}

		// 2. Scoped / Custom AI CSS Rules
		if ( ! empty( $rules ) && is_array( $rules ) ) {
			foreach ( $rules as $rule ) {
				if ( empty( $rule['css'] ) ) {
					continue;
				}
				if ( ! self::matches_scope( isset( $rule['scope'] ) ? $rule['scope'] : 'global' ) ) {
					continue;
				}
				$label = ! empty( $rule['label'] ) ? wp_strip_all_tags( $rule['label'] ) : 'Rule';
				$css  .= "\n/* [Rule] {$label} */\n" . $rule['css'] . "\n";
			}
		}

		return $css;
	}

	/**
	 * Check if a scope ('global', 'home', 'posts', 'pages') matches the current frontend request.
	 *
	 * @param string $scope Target scope.
	 * @return bool
	 */
	public static function matches_scope( $scope ) {
		if ( empty( $scope ) || 'global' === $scope ) {
			return true;
		}
		if ( 'home' === $scope && ( is_front_page() || is_home() ) ) {
			return true;
		}
		if ( 'posts' === $scope && is_single() ) {
			return true;
		}
		if ( 'pages' === $scope && is_page() ) {
			return true;
		}
		return false;
	}

	/**
	 * Enqueue the virtual runtime CSS using `wp_register_style` + `wp_add_inline_style`
	 * in accordance with WordPress.org Plugin Guidelines, while also exposing `#wsua-custom-ui`
	 * for live zero-reload DOM preview updates.
	 */
	public static function enqueue_compiled_css() {
		if ( ! WSUA_Safety_Guard::should_apply_adjustments() ) {
			return;
		}

		$css = self::compile_frontend_css();
		wp_register_style( 'wsua-custom-ui', false, array(), WSUA_VERSION );
		wp_enqueue_style( 'wsua-custom-ui' );
		wp_add_inline_style( 'wsua-custom-ui', $css );
	}

	/**
	 * Output non-destructive DOM patches (text overrides, announcement banners) and Safe Mode recovery banner if active.
	 */
	public static function render_dom_patches_and_safe_banner() {
		// If Safe Mode bypass is active and user is admin, show a sleek recovery notice bar
		if ( WSUA_Safety_Guard::is_safe_mode_active() && current_user_can( 'manage_options' ) ) {
			$exit_url   = esc_url( add_query_arg( 'wsua_safe_mode', '0' ) );
			$studio_url = esc_url( admin_url( 'admin.php?page=wp-safe-ui-adjuster' ) );
			?>
			<div id="wsua-safe-mode-bar" style="position:fixed;bottom:0;left:0;right:0;background:#b91c1c;color:#fff;padding:10px 20px;z-index:999999;display:flex;justify-content:space-between;align-items:center;font-family:sans-serif;font-size:13px;box-shadow:0 -2px 10px rgba(0,0,0,0.2);">
				<span><strong><?php esc_html_e( 'WP Safe UI Adjuster — Emergency Safe Mode Active:', 'safe-ui-adjuster' ); ?></strong> <?php esc_html_e( 'All frontend CSS & DOM adjustments are temporarily bypassed.', 'safe-ui-adjuster' ); ?></span>
				<span style="display:flex;gap:10px;">
					<a href="<?php echo $studio_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="color:#fff;text-decoration:underline;"><?php esc_html_e( 'Open AI Studio & Rollback', 'safe-ui-adjuster' ); ?></a>
					<a href="<?php echo $exit_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" style="background:#fff;color:#b91c1c;padding:4px 10px;border-radius:4px;text-decoration:none;font-weight:600;"><?php esc_html_e( 'Exit Safe Mode', 'safe-ui-adjuster' ); ?></a>
				</span>
			</div>
			<?php
			return;
		}

		if ( ! WSUA_Safety_Guard::should_apply_adjustments() ) {
			return;
		}

		$state   = WSUA_Safety_Guard::get_active_state();
		$patches = isset( $state['dom_patches'] ) && is_array( $state['dom_patches'] ) ? $state['dom_patches'] : array();

		if ( empty( $patches ) ) {
			return;
		}

		$active_patches = array();
		foreach ( $patches as $patch ) {
			if ( self::matches_scope( isset( $patch['scope'] ) ? $patch['scope'] : 'global' ) ) {
				$active_patches[] = $patch;
			}
		}

		if ( empty( $active_patches ) ) {
			return;
		}
		?>
		<script id="wsua-dom-patcher">
		(function() {
			var patches = <?php echo wp_json_encode( $active_patches ); ?>;
			function applyPatches(list) {
				// Clear previous injected banners before re-applying
				document.querySelectorAll('[data-wsua-injected="1"]').forEach(function(el) { el.remove(); });
				list.forEach(function(p) {
					if (!p || !p.selector) return;
					try {
						if (p.type === 'inject_banner') {
							var target = document.querySelector(p.selector) || document.body;
							var bar = document.createElement('div');
							bar.setAttribute('data-wsua-injected', '1');
							bar.className = 'wsua-announcement-banner';
							if (p.style) bar.style.cssText = p.style;
							bar.innerHTML = p.content;
							if (p.position === 'bottom') {
								target.appendChild(bar);
							} else {
								target.insertBefore(bar, target.firstChild);
							}
						} else if (p.type === 'replace_text') {
							document.querySelectorAll(p.selector).forEach(function(el) {
								if (el.closest('#wsua-chat-drawer')) return;
								if (!el.hasAttribute('data-wsua-orig-text')) {
									el.setAttribute('data-wsua-orig-text', el.textContent);
								}
								el.textContent = p.content;
							});
						} else if (p.type === 'append_badge') {
							document.querySelectorAll(p.selector).forEach(function(el) {
								if (el.closest('#wsua-chat-drawer')) return;
								var badge = document.createElement('span');
								badge.setAttribute('data-wsua-injected', '1');
								badge.style.cssText = p.style || 'display:inline-block;margin-left:8px;padding:2px 8px;font-size:11px;border-radius:999px;background:#2563eb;color:#fff;font-weight:600;';
								badge.innerHTML = p.content;
								el.appendChild(badge);
							});
						}
					} catch (e) {}
				});
			}
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', function() { applyPatches(patches); });
			} else {
				applyPatches(patches);
			}
			window.WSUA_ApplyDOMPatches = applyPatches;
		})();
		</script>
		<?php
	}
}
