<?php
/**
 * AES-256-CBC Encryption for Gemini, OpenAI, and Anthropic Claude API keys.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_Crypto {

	/**
	 * Cipher algorithm.
	 */
	const CIPHER = 'AES-256-CBC';

	/**
	 * Derive a 32-byte encryption key from WordPress security salts.
	 *
	 * @return string
	 */
	private static function get_key() {
		$salt  = defined( 'AUTH_KEY' ) ? AUTH_KEY : 'wsua-fallback-key-1';
		$salt .= defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : 'wsua-fallback-key-2';
		return hash( 'sha256', $salt, true );
	}

	/**
	 * Encrypt a plaintext API key.
	 *
	 * @param string $plaintext Plaintext secret.
	 * @return string
	 */
	public static function encrypt( $plaintext ) {
		if ( empty( $plaintext ) ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return base64_encode( $plaintext );
		}

		$key    = self::get_key();
		$iv_len = openssl_cipher_iv_length( self::CIPHER );
		$iv     = openssl_random_pseudo_bytes( $iv_len );
		$raw    = openssl_encrypt( $plaintext, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv );
		$hmac   = hash_hmac( 'sha256', $iv . $raw, $key, true );

		return base64_encode( $iv . $hmac . $raw );
	}

	/**
	 * Decrypt an encrypted API key.
	 *
	 * @param string $encoded Encrypted string.
	 * @return string
	 */
	public static function decrypt( $encoded ) {
		if ( empty( $encoded ) ) {
			return '';
		}
		$decoded = base64_decode( $encoded, true );
		if ( false === $decoded ) {
			return '';
		}
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return $decoded;
		}

		$key    = self::get_key();
		$iv_len = openssl_cipher_iv_length( self::CIPHER );
		if ( strlen( $decoded ) <= ( $iv_len + 32 ) ) {
			return '';
		}

		$iv         = substr( $decoded, 0, $iv_len );
		$hmac       = substr( $decoded, $iv_len, 32 );
		$ciphertext = substr( $decoded, $iv_len + 32 );
		$calc_hmac  = hash_hmac( 'sha256', $iv . $ciphertext, $key, true );

		if ( ! hash_equals( $hmac, $calc_hmac ) ) {
			return '';
		}

		$decrypted = openssl_decrypt( $ciphertext, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv );
		return false !== $decrypted ? $decrypted : '';
	}
}
