<?php
/**
 * Antigravity-Style Floating Frontend Chat Drawer & Point-and-Click Element Selector.
 * Visible ONLY to logged-in Administrators when browsing the site.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_Frontend_Drawer {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_drawer_assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_drawer_markup' ), 1000 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'add_admin_bar_toggle' ), 100 );
	}

	/**
	 * Check if the Floating Chat Drawer should load on this frontend view.
	 *
	 * @return bool
	 */
	private static function should_load_drawer() {
		if ( is_admin() || ! current_user_can( 'manage_options' ) ) {
			return false;
		}
		// Do not render nested floating drawer inside the Admin Studio preview iframe
		if ( isset( $_GET['wsua_studio_preview'] ) && '1' === $_GET['wsua_studio_preview'] ) {
			return false;
		}
		$settings = WSUA_AI_Agent::get_settings();
		return ! empty( $settings['enable_front_chat'] );
	}

	/**
	 * Add a quick button in the WordPress Top Admin Bar to open the AI UI Chat Drawer.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar object.
	 */
	public static function add_admin_bar_toggle( $wp_admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$state = WSUA_Safety_Guard::get_active_state();
		$badge = ( 'live' === $state['deploy_mode'] ) ? 'LIVE' : 'PREVIEW';

		$wp_admin_bar->add_node(
			array(
				'id'    => 'wsua-ai-chat-toggle',
				'title' => sprintf( 'AI UI Chat (%s)', $badge ),
				'href'  => is_admin() ? admin_url( 'admin.php?page=wp-safe-ui-adjuster' ) : '#wsua-toggle-chat',
				'meta'  => array(
					'title' => __( 'Toggle AI UI Chat Drawer (Ctrl+Shift+U)', 'safe-ui-adjuster' ),
				),
			)
		);
	}

	/**
	 * Enqueue Floating Chat Drawer CSS & JS on the frontend for Administrators.
	 */
	public static function enqueue_drawer_assets() {
		// If loaded inside the Admin Studio preview iframe, load the element picker bridge
		$is_iframe = isset( $_GET['wsua_studio_preview'] ) && '1' === $_GET['wsua_studio_preview'] && current_user_can( 'manage_options' );

		if ( ! self::should_load_drawer() && ! $is_iframe ) {
			return;
		}

		wp_enqueue_style(
			'wsua-chat-drawer-css',
			WSUA_PLUGIN_URL . 'assets/css/chat-drawer.css',
			array(),
			WSUA_VERSION
		);

		wp_enqueue_script(
			'wsua-chat-drawer-js',
			WSUA_PLUGIN_URL . 'assets/js/chat-drawer.js',
			array(),
			WSUA_VERSION,
			true
		);

		$state    = WSUA_Safety_Guard::get_active_state();
		$settings = WSUA_AI_Agent::get_settings();
		$history  = get_option( WSUA_OPT_CHAT_HISTORY, array() );

		wp_localize_script(
			'wsua-chat-drawer-js',
			'WSUA_DrawerConfig',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'studioUrl'    => admin_url( 'admin.php?page=wp-safe-ui-adjuster' ),
				'nonce'        => wp_create_nonce( 'wsua_chat_nonce' ),
				'deployMode'   => $state['deploy_mode'],
				'provider'     => $settings['provider'],
				'history'      => array_slice( is_array( $history ) ? $history : array(), -15 ),
				'isIframe'     => $is_iframe,
				'pageContext'  => array(
					'url'      => home_url( add_query_arg( array() ) ),
					'pageType' => is_front_page() ? 'home' : ( is_single() ? 'post' : ( is_page() ? 'page' : 'archive' ) ),
					'theme'    => wp_get_theme()->get( 'Name' ),
				),
			)
		);
	}

	/**
	 * Render the Floating Chat Drawer HTML in `wp_footer`.
	 */
	public static function render_drawer_markup() {
		if ( ! self::should_load_drawer() ) {
			return;
		}

		$state    = WSUA_Safety_Guard::get_active_state();
		$settings = WSUA_AI_Agent::get_settings();
		$is_live  = ( 'live' === $state['deploy_mode'] );
		?>
		<div id="wsua-chat-drawer" class="wsua-drawer-closed" data-nosnippet>
			<!-- Floating Launcher Pill -->
			<button type="button" id="wsua-launcher-btn" title="<?php esc_attr_e( 'Open AI UI Adjuster (Ctrl+Shift+U)', 'safe-ui-adjuster' ); ?>">
				<span class="wsua-launcher-label"><?php esc_html_e( 'AI UI Chat', 'safe-ui-adjuster' ); ?></span>
				<span class="wsua-mode-pill <?php echo $is_live ? 'wsua-pill-live' : 'wsua-pill-preview'; ?>" id="wsua-launcher-mode">
					<?php echo $is_live ? esc_html__( 'LIVE', 'safe-ui-adjuster' ) : esc_html__( 'PREVIEW', 'safe-ui-adjuster' ); ?>
				</span>
			</button>

			<!-- Expandable Antigravity-Style Chat Panel -->
			<div class="wsua-panel">
				<div class="wsua-panel-header">
					<div class="wsua-panel-title">
						<div>
							<strong><?php esc_html_e( 'WP Safe UI Agent', 'safe-ui-adjuster' ); ?></strong>
							<span class="wsua-provider-tag"><?php echo esc_html( strtoupper( $settings['provider'] ) ); ?></span>
						</div>
					</div>
					<div class="wsua-panel-controls">
						<button type="button" id="wsua-toggle-mode-btn" class="wsua-mode-switch <?php echo $is_live ? 'is-live' : 'is-preview'; ?>" title="<?php esc_attr_e( 'Switch between Admin Preview and Live for all visitors', 'safe-ui-adjuster' ); ?>">
							<?php echo $is_live ? esc_html__( '● Live', 'safe-ui-adjuster' ) : esc_html__( '◐ Preview Only', 'safe-ui-adjuster' ); ?>
						</button>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-safe-ui-adjuster' ) ); ?>" class="wsua-icon-btn" title="<?php esc_attr_e( 'Open Full Split-Screen AI Studio in WP Admin', 'safe-ui-adjuster' ); ?>">⤢</a>
						<button type="button" id="wsua-close-btn" class="wsua-icon-btn" title="<?php esc_attr_e( 'Minimize (Ctrl+Shift+U)', 'safe-ui-adjuster' ); ?>">✕</button>
					</div>
				</div>

				<!-- Quick Prompt Suggestions -->
				<div class="wsua-quick-chips">
					<button type="button" class="wsua-chip" data-prompt="Make the header sticky with a blurred glass background"><?php esc_html_e( 'Sticky glass header', 'safe-ui-adjuster' ); ?></button>
					<button type="button" class="wsua-chip" data-prompt="Add an announcement banner saying 'Welcome to our updated website!'"><?php esc_html_e( '+ Announcement banner', 'safe-ui-adjuster' ); ?></button>
					<button type="button" class="wsua-chip" data-prompt="Set button accent color to #2563eb"><?php esc_html_e( 'Blue accent buttons', 'safe-ui-adjuster' ); ?></button>
					<button type="button" class="wsua-chip" data-prompt="Hide comments menu and embed blocks for authors"><?php esc_html_e( 'Clean Author UI', 'safe-ui-adjuster' ); ?></button>
				</div>

				<!-- Chat Thread Area -->
				<div class="wsua-messages" id="wsua-messages"></div>

				<!-- Selected Element Context Bar -->
				<div class="wsua-selected-bar" id="wsua-selected-bar" style="display:none;">
					<span class="wsua-selected-label">@selected: <code id="wsua-selected-code"></code></span>
					<button type="button" id="wsua-clear-selected" title="<?php esc_attr_e( 'Clear selection', 'safe-ui-adjuster' ); ?>">✕</button>
				</div>

				<!-- Composer Input -->
				<form id="wsua-chat-form" class="wsua-composer">
					<button type="button" id="wsua-pick-element-btn" class="wsua-picker-btn" title="<?php esc_attr_e( 'Point & Click any element on the page to target it', 'safe-ui-adjuster' ); ?>">
						⊕
					</button>
					<textarea id="wsua-chat-input" rows="1" placeholder="<?php esc_attr_e( 'Ask to adjust layout, colors, text, or click ⊕ to pick an element...', 'safe-ui-adjuster' ); ?>"></textarea>
					<button type="submit" id="wsua-send-btn" class="wsua-send-btn" title="<?php esc_attr_e( 'Apply UI Adjustment', 'safe-ui-adjuster' ); ?>">
						↑
					</button>
				</form>
			</div>
		</div>
		<?php
	}
}
