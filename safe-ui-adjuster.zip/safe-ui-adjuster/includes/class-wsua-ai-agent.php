<?php
/**
 * Antigravity-Style Conversational AI UI Agent:
 * - Multi-Provider BYOK support: Google Gemini, OpenAI, and Anthropic Claude.
 * - Built-in Instant Local Command Parser (works with zero API latency or before an API key is added).
 * - Translates natural-language chat + Point-and-Click @selected element context into structured safe operations:
 *   1. Visual Tokens & Scoped CSS Rules (`css_rules`)
 *   2. Non-Destructive Content & DOM Patches (`dom_patches`: banners, text overrides, badges)
 *   3. Gutenberg & Role-Based Admin UI Rules (`role_ui_rules`)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_AI_Agent {

	/**
	 * Get AI provider settings.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$saved    = get_option( WSUA_OPT_SETTINGS, array() );
		$defaults = array(
			'provider'          => 'gemini', // 'gemini', 'openai', 'claude'
			'gemini_model'      => 'gemini-2.5-flash',
			'openai_model'      => 'gpt-4o-mini',
			'claude_model'      => 'claude-3-7-sonnet-latest',
			'gemini_key_enc'    => '',
			'openai_key_enc'    => '',
			'claude_key_enc'    => '',
			'enable_front_chat' => true,
		);
		return wp_parse_args( $saved, $defaults );
	}

	/**
	 * Process a user chat message and apply resulting safe UI operations.
	 *
	 * @param string $prompt           User's natural language request.
	 * @param array  $selected_element Optional point-and-click selected element context [selector, tagName, text, styles].
	 * @param array  $page_context     Optional current page metadata [url, pageType, theme].
	 * @return array                   Normalized response with assistant reply, actions taken, updated state, and snapshot ID.
	 */
	public static function handle_chat_turn( $prompt, $selected_element = array(), $page_context = array() ) {
		$prompt        = trim( sanitize_textarea_field( $prompt ) );
		$current_state = WSUA_Safety_Guard::get_active_state();
		$settings      = self::get_settings();

		// 1. Check if an API key is configured for the selected provider; if so, call the LLM, else use Local Smart Engine.
		$api_key      = self::get_active_api_key( $settings );
		$ai_plan      = null;
		$used_engine  = 'local';

		if ( ! empty( $api_key ) ) {
			$llm_result = self::call_provider_llm( $settings['provider'], $api_key, $settings, $prompt, $selected_element, $page_context, $current_state );
			if ( ! is_wp_error( $llm_result ) && is_array( $llm_result ) ) {
				$ai_plan     = $llm_result;
				$used_engine = $settings['provider'];
			}
		}

		// Fallback or primary Local Smart Engine when no API key is set or if local deterministic parse is needed.
		if ( null === $ai_plan ) {
			$ai_plan = self::parse_with_local_smart_engine( $prompt, $selected_element, $page_context, $current_state );
			if ( ! empty( $api_key ) && isset( $llm_result ) && is_wp_error( $llm_result ) ) {
				$ai_plan['reply'] .= ' (Note: Cloud AI returned "' . $llm_result->get_error_message() . '", so I applied this using the built-in Local UI Engine.)';
			}
		}

		// Apply structured plan safely to state
		$applied = self::apply_structured_plan( $ai_plan, $current_state, $prompt );

		// Record turn in chat history
		$history = get_option( WSUA_OPT_CHAT_HISTORY, array() );
		if ( ! is_array( $history ) ) {
			$history = array();
		}

		$turn_entry = array(
			'id'               => 'turn_' . uniqid(),
			'time'             => current_time( 'H:i' ),
			'user_prompt'      => $prompt,
			'selected_element' => ! empty( $selected_element['selector'] ) ? $selected_element['selector'] : '',
			'assistant_reply'  => $applied['reply'],
			'actions_summary'  => $applied['actions_summary'],
			'snapshot_id'      => $applied['snapshot_id'],
			'engine'           => $used_engine,
		);

		$history[] = $turn_entry;
		$history   = array_slice( $history, -40 ); // Keep last 40 chat turns
		update_option( WSUA_OPT_CHAT_HISTORY, $history, false );

		return array(
			'turn'         => $turn_entry,
			'state'        => $applied['new_state'],
			'compiled_css' => WSUA_Runtime_Engine::compile_frontend_css( $applied['new_state'] ),
			'dom_patches'  => $applied['new_state']['dom_patches'],
		);
	}

	/**
	 * Get decrypted API key for the active provider.
	 *
	 * @param array $settings Plugin settings.
	 * @return string
	 */
	private static function get_active_api_key( $settings ) {
		$provider = isset( $settings['provider'] ) ? $settings['provider'] : 'gemini';
		$field    = $provider . '_key_enc';
		return ! empty( $settings[ $field ] ) ? WSUA_Crypto::decrypt( $settings[ $field ] ) : '';
	}

	/**
	 * Build the system instruction enforcing the strict Safe Action JSON schema.
	 *
	 * @param array $selected_element Selected DOM element metadata.
	 * @param array $page_context     Current page metadata.
	 * @param array $current_state    Current active UI rules.
	 * @return string
	 */
	private static function build_system_prompt( $selected_element, $page_context, $current_state ) {
		$theme_name = wp_get_theme()->get( 'Name' );
		$sel_json   = ! empty( $selected_element ) ? wp_json_encode( $selected_element ) : 'None';
		$page_json  = ! empty( $page_context ) ? wp_json_encode( $page_context ) : '{}';
		$tokens_str = wp_json_encode( $current_state['tokens'] );

		return <<<PROMPT
You are the Antigravity WordPress Safe UI Agent running inside the user's WordPress site (Active Theme: {$theme_name}).
Your job is to translate the user's natural language UI request into a strict JSON object that non-destructively adjusts the WordPress UI without ever breaking the website.

CONTEXT:
- Point-and-click Selected Element (@selected): {$sel_json}
- Current Page Context: {$page_json}
- Current Active Tokens: {$tokens_str}

RESPOND ONLY WITH A VALID JSON OBJECT matching this exact schema (no markdown code fences around it):
{
  "reply": "Concise, friendly explanation of what you adjusted and how it works.",
  "tokens": {
    "max_width": "optional string e.g. 1200px",
    "accent_color": "optional hex/rgb color for buttons and links",
    "bg_color": "optional page background color",
    "text_color": "optional body text color",
    "base_font_size": "optional string e.g. 17px",
    "font_family": "optional font stack string",
    "sticky_header": true or false or null,
    "hide_selectors": ["optional array of CSS selectors to hide"]
  },
  "css_rules": [
    {
      "label": "Short description of CSS tweak",
      "scope": "global",
      "css": "Valid CSS rules with balanced curly braces {}. Use @selected's selector if the user referred to 'this element' or '@selected'."
    }
  ],
  "dom_patches": [
    {
      "type": "replace_text | inject_banner | append_badge",
      "selector": "CSS selector (or 'body' for top announcement banner)",
      "content": "Safe text or inline HTML content",
      "position": "top | bottom | replace",
      "style": "Optional inline CSS style for banner/badge",
      "scope": "global"
    }
  ],
  "role_ui_rules": {
    "role_name (editor|author|contributor|subscriber)": {
      "hide_menus": ["optional slugs: edit-comments.php, tools.php, plugins.php, options-general.php, edit.php"],
      "hide_panels": ["optional Gutenberg panels: discussion-panel, featured-image, post-excerpt, taxonomy-panel-category, taxonomy-panel-post_tag"],
      "hide_blocks": ["optional block names or prefixes: core/embed, core/html, core/shortcode, core/archives"]
    }
  },
  "clear_all": false
}

RULES:
1. Never output raw PHP or <script> tags.
2. When @selected has a selector and the user says "this", "make it...", "hide this", or "change this button", target that exact selector.
3. Keep CSS clean, specific, and use !important only when needed to override theme defaults.
PROMPT;
	}

	/**
	 * Dispatch prompt to Google Gemini, OpenAI, or Anthropic Claude.
	 *
	 * @param string $provider         'gemini' | 'openai' | 'claude'.
	 * @param string $api_key          Decrypted API key.
	 * @param array  $settings         Settings array.
	 * @param string $prompt           User message.
	 * @param array  $selected_element Selected element info.
	 * @param array  $page_context     Page context.
	 * @param array  $current_state    Current active UI state.
	 * @return array|WP_Error
	 */
	private static function call_provider_llm( $provider, $api_key, $settings, $prompt, $selected_element, $page_context, $current_state ) {
		$system_prompt = self::build_system_prompt( $selected_element, $page_context, $current_state );

		if ( 'gemini' === $provider ) {
			$model = ! empty( $settings['gemini_model'] ) ? $settings['gemini_model'] : 'gemini-2.5-flash';
			$url   = sprintf( 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', rawurlencode( $model ), rawurlencode( $api_key ) );
			$body  = array(
				'systemInstruction' => array(
					'parts' => array( array( 'text' => $system_prompt ) ),
				),
				'contents'          => array(
					array(
						'role'  => 'user',
						'parts' => array( array( 'text' => $prompt ) ),
					),
				),
				'generationConfig'  => array(
					'temperature'      => 0.2,
					'responseMimeType' => 'application/json',
				),
			);

			$res = wp_remote_post(
				$url,
				array(
					'timeout' => 30,
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => wp_json_encode( $body ),
				)
			);

			if ( is_wp_error( $res ) ) {
				return $res;
			}
			$json = json_decode( wp_remote_retrieve_body( $res ), true );
			$text = isset( $json['candidates'][0]['content']['parts'][0]['text'] ) ? $json['candidates'][0]['content']['parts'][0]['text'] : '';
			return self::decode_llm_json( $text, $json );
		}

		if ( 'openai' === $provider ) {
			$model = ! empty( $settings['openai_model'] ) ? $settings['openai_model'] : 'gpt-4o-mini';
			$res   = wp_remote_post(
				'https://api.openai.com/v1/chat/completions',
				array(
					'timeout' => 30,
					'headers' => array(
						'Content-Type'  => 'application/json',
						'Authorization' => 'Bearer ' . $api_key,
					),
					'body'    => wp_json_encode(
						array(
							'model'           => $model,
							'temperature'     => 0.2,
							'response_format' => array( 'type' => 'json_object' ),
							'messages'        => array(
								array( 'role' => 'system', 'content' => $system_prompt ),
								array( 'role' => 'user', 'content' => $prompt ),
							),
						)
					),
				)
			);

			if ( is_wp_error( $res ) ) {
				return $res;
			}
			$json = json_decode( wp_remote_retrieve_body( $res ), true );
			$text = isset( $json['choices'][0]['message']['content'] ) ? $json['choices'][0]['message']['content'] : '';
			return self::decode_llm_json( $text, $json );
		}

		if ( 'claude' === $provider ) {
			$model = ! empty( $settings['claude_model'] ) ? $settings['claude_model'] : 'claude-3-7-sonnet-latest';
			$res   = wp_remote_post(
				'https://api.anthropic.com/v1/messages',
				array(
					'timeout' => 30,
					'headers' => array(
						'Content-Type'      => 'application/json',
						'x-api-key'         => $api_key,
						'anthropic-version' => '2023-06-01',
					),
					'body'    => wp_json_encode(
						array(
							'model'      => $model,
							'max_tokens' => 1500,
							'system'     => $system_prompt,
							'messages'   => array(
								array( 'role' => 'user', 'content' => $prompt ),
							),
						)
					),
				)
			);

			if ( is_wp_error( $res ) ) {
				return $res;
			}
			$json = json_decode( wp_remote_retrieve_body( $res ), true );
			$text = isset( $json['content'][0]['text'] ) ? $json['content'][0]['text'] : '';
			return self::decode_llm_json( $text, $json );
		}

		return new WP_Error( 'wsua_unknown_provider', __( 'Unknown AI provider selected.', 'safe-ui-adjuster' ) );
	}

	/**
	 * Extract and parse JSON object from LLM text response.
	 *
	 * @param string $text Raw text from LLM.
	 * @param array  $raw  Full API payload for error reporting.
	 * @return array|WP_Error
	 */
	private static function decode_llm_json( $text, $raw = array() ) {
		if ( empty( $text ) ) {
			$err = isset( $raw['error']['message'] ) ? $raw['error']['message'] : __( 'Empty response from AI provider.', 'safe-ui-adjuster' );
			return new WP_Error( 'wsua_llm_empty', $err );
		}

		$clean = trim( $text );
		$clean = preg_replace( '/^```(?:json)?\s*/i', '', $clean );
		$clean = preg_replace( '/\s*```$/', '', $clean );

		$decoded = json_decode( $clean, true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'wsua_llm_bad_json', __( 'AI provider did not return valid JSON.', 'safe-ui-adjuster' ) );
		}

		return $decoded;
	}

	/**
	 * Built-in Local Smart Command Parser:
	 * Handles natural language UI adjustments deterministically even without an external API key!
	 *
	 * @param string $prompt           User message.
	 * @param array  $selected_element Point-and-click element context.
	 * @param array  $page_context     Page context.
	 * @param array  $current_state    Current UI state.
	 * @return array
	 */
	public static function parse_with_local_smart_engine( $prompt, $selected_element, $page_context, $current_state ) {
		$lower    = strtolower( $prompt );
		$selector = ! empty( $selected_element['selector'] ) ? $selected_element['selector'] : '';

		$plan = array(
			'reply'         => '',
			'tokens'        => array(),
			'css_rules'     => array(),
			'dom_patches'   => array(),
			'role_ui_rules' => array(),
			'clear_all'     => false,
		);

		$matched_descriptions = array();

		// 0. Check for Reset / Clear all
		if ( preg_match( '/\b(reset all|clear all|remove all adjustments|restore default)\b/i', $lower ) ) {
			$plan['clear_all'] = true;
			$plan['reply']     = __( 'I have cleared all active UI adjustments and restored your site\'s default appearance.', 'safe-ui-adjuster' );
			return $plan;
		}

		// 1. Sticky / Glass Header
		if ( strpos( $lower, 'sticky' ) !== false && ( strpos( $lower, 'header' ) !== false || strpos( $lower, 'nav' ) !== false || ! empty( $selector ) ) ) {
			$target = ! empty( $selector ) ? $selector : 'header, .site-header, #masthead, .wp-block-template-part';
			$blur   = ( strpos( $lower, 'glass' ) !== false || strpos( $lower, 'blur' ) !== false )
				? 'backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); background-color: rgba(255, 255, 255, 0.85) !important;'
				: '';
			$plan['tokens']['sticky_header'] = true;
			$plan['css_rules'][]             = array(
				'label' => 'Sticky Header Adjustment',
				'scope' => 'global',
				'css'   => "{$target} { position: sticky !important; top: 0 !important; z-index: 999 !important; {$blur} box-shadow: 0 4px 20px rgba(0,0,0,0.06); }",
			);
			$matched_descriptions[]          = sprintf( __( 'made `%s` sticky at the top of the viewport', 'safe-ui-adjuster' ), $target );
		}

		// 2. Hide Element (@selected or named element like footer, breadcrumbs, page title, sidebar)
		if ( preg_match( '/\b(hide|remove)\b/i', $lower ) && strpos( $lower, 'menu' ) === false && strpos( $lower, 'block' ) === false && strpos( $lower, 'panel' ) === false ) {
			$hide_target = $selector;
			if ( empty( $hide_target ) ) {
				if ( strpos( $lower, 'breadcrumb' ) !== false ) {
					$hide_target = '.breadcrumbs, .yoast-breadcrumb, .rank-math-breadcrumb, nav.woocommerce-breadcrumb';
				} elseif ( strpos( $lower, 'page title' ) !== false || strpos( $lower, 'entry title' ) !== false ) {
					$hide_target = '.page .entry-title, .page .wp-block-post-title, .page-title';
				} elseif ( strpos( $lower, 'footer' ) !== false ) {
					$hide_target = 'footer, .site-footer, #colophon';
				} elseif ( strpos( $lower, 'sidebar' ) !== false ) {
					$hide_target = 'aside, #secondary, .sidebar, .widget-area';
				} elseif ( strpos( $lower, 'author' ) !== false && strpos( $lower, 'box' ) !== false ) {
					$hide_target = '.author-bio, .author-box, .wp-block-post-author';
				}
			}

			if ( ! empty( $hide_target ) ) {
				$plan['tokens']['hide_selectors'] = array( $hide_target );
				$matched_descriptions[]           = sprintf( __( 'hidden `%s` non-destructively via scoped CSS', 'safe-ui-adjuster' ), $hide_target );
			}
		}

		// 3. Container Max Width (e.g., "set max width to 1200px" or "wider layout 1320px")
		if ( preg_match( '/(?:max[\s\-]*width|container|width)[^\d]*(\d{3,4})\s*(px|rem|%)/i', $prompt, $m ) ) {
			$width                       = $m[1] . strtolower( $m[2] );
			$plan['tokens']['max_width'] = $width;
			$matched_descriptions[]      = sprintf( __( 'set the site container max-width to `%s`', 'safe-ui-adjuster' ), $width );
		}

		// 4. Font Size Adjustment (e.g. "font size to 18px" or "increase font size")
		if ( preg_match( '/font[\s\-]*size[^\d]*(\d{2})\s*(px|rem)/i', $prompt, $m ) ) {
			$size = $m[1] . strtolower( $m[2] );
			if ( ! empty( $selector ) ) {
				$plan['css_rules'][] = array(
					'label' => 'Font Size on ' . $selector,
					'scope' => 'global',
					'css'   => "{$selector} { font-size: {$size} !important; }",
				);
				$matched_descriptions[] = sprintf( __( 'updated font-size on `%1$s` to `%2$s`', 'safe-ui-adjuster' ), $selector, $size );
			} else {
				$plan['tokens']['base_font_size'] = $size;
				$matched_descriptions[]           = sprintf( __( 'updated base body font-size to `%s`', 'safe-ui-adjuster' ), $size );
			}
		}

		// 5. Color Changes (Hex code #xxxxxx or named colors on @selected, background, text, or buttons/accent)
		$color_val = '';
		if ( preg_match( '/(#[0-9a-fA-F]{3,8})\b/', $prompt, $cm ) ) {
			$color_val = $cm[1];
		} else {
			$named_colors = array(
				'navy'    => '#0f172a',
				'blue'    => '#2563eb',
				'indigo'  => '#4f46e5',
				'purple'  => '#7c3aed',
				'emerald' => '#10b981',
				'green'   => '#16a34a',
				'red'     => '#dc2626',
				'orange'  => '#ea580c',
				'amber'   => '#d97706',
				'Gold'    => '#eab308',
				'dark'    => '#111827',
				'black'   => '#000000',
				'white'   => '#ffffff',
				'slate'   => '#334155',
			);
			foreach ( $named_colors as $name => $hex ) {
				if ( preg_match( '/\b' . preg_quote( strtolower( $name ), '/' ) . '\b/', $lower ) && ( strpos( $lower, 'color' ) !== false || strpos( $lower, 'background' ) !== false || strpos( $lower, 'button' ) !== false || ! empty( $selector ) ) ) {
					$color_val = $hex;
					break;
				}
			}
		}

		if ( ! empty( $color_val ) ) {
			if ( ! empty( $selector ) ) {
				$prop = ( strpos( $lower, 'background' ) !== false || strpos( $lower, 'bg' ) !== false || strpos( $lower, 'button' ) !== false ) ? 'background-color' : 'color';
				$extra = ( 'background-color' === $prop && in_array( strtolower( $color_val ), array( '#0f172a', '#2563eb', '#4f46e5', '#7c3aed', '#111827', '#000000', '#dc2626', '#16a34a' ), true ) ) ? ' color: #ffffff !important;' : '';
				$plan['css_rules'][] = array(
					'label' => "Color adjustment on {$selector}",
					'scope' => 'global',
					'css'   => "{$selector} { {$prop}: {$color_val} !important;{$extra} }",
				);
				$matched_descriptions[] = sprintf( __( 'set `%1$s` on `%2$s` to `%3$s`', 'safe-ui-adjuster' ), $prop, $selector, $color_val );
			} elseif ( strpos( $lower, 'button' ) !== false || strpos( $lower, 'accent' ) !== false || strpos( $lower, 'link' ) !== false ) {
				$plan['tokens']['accent_color'] = $color_val;
				$matched_descriptions[]         = sprintf( __( 'set global button & link accent color to `%s`', 'safe-ui-adjuster' ), $color_val );
			} elseif ( strpos( $lower, 'background' ) !== false || strpos( $lower, 'page bg' ) !== false ) {
				$plan['tokens']['bg_color'] = $color_val;
				$matched_descriptions[]     = sprintf( __( 'set site background color to `%s`', 'safe-ui-adjuster' ), $color_val );
			} else {
				$plan['tokens']['text_color'] = $color_val;
				$matched_descriptions[]       = sprintf( __( 'set primary text color to `%s`', 'safe-ui-adjuster' ), $color_val );
			}
		}

		// 6. Rounded corners / Border radius / Shadow / Padding on @selected
		if ( ! empty( $selector ) && ( strpos( $lower, 'round' ) !== false || strpos( $lower, 'radius' ) !== false || strpos( $lower, 'pill' ) !== false ) ) {
			$radius = strpos( $lower, 'pill' ) !== false ? '9999px' : '12px';
			if ( preg_match( '/(\d+)\s*px/', $lower, $rm ) ) {
				$radius = $rm[1] . 'px';
			}
			$plan['css_rules'][] = array(
				'label' => "Border radius on {$selector}",
				'scope' => 'global',
				'css'   => "{$selector} { border-radius: {$radius} !important; }",
			);
			$matched_descriptions[] = sprintf( __( 'applied `%1$s` rounded corners to `%2$s`', 'safe-ui-adjuster' ), $radius, $selector );
		}

		// 7. DOM Patch: Add Announcement Banner (e.g., "add an announcement banner saying 'Welcome to our new site!'")
		if ( ( strpos( $lower, 'banner' ) !== false || strpos( $lower, 'announcement' ) !== false || strpos( $lower, 'notice bar' ) !== false ) && preg_match( '/["\']([^"\']+)["\']/', $prompt, $bm ) ) {
			$banner_text           = $bm[1];
			$bg                    = ! empty( $color_val ) ? $color_val : '#0f172a';
			$plan['dom_patches'][] = array(
				'type'     => 'inject_banner',
				'selector' => 'body',
				'content'  => $banner_text,
				'position' => 'top',
				'style'    => "background:{$bg};color:#ffffff;text-align:center;padding:10px 18px;font-size:14px;font-weight:600;z-index:99999;position:relative;",
				'scope'    => 'global',
			);
			$matched_descriptions[] = sprintf( __( 'injected a top announcement banner: "%s"', 'safe-ui-adjuster' ), $banner_text );
		}

		// 8. DOM Patch: Change Text of @selected (e.g. "change text to 'Get Started Free'" or "rewrite heading to 'Welcome'")
		if ( ! empty( $selector ) && ( strpos( $lower, 'text' ) !== false || strpos( $lower, 'change to' ) !== false || strpos( $lower, 'rewrite' ) !== false || strpos( $lower, 'rename' ) !== false || strpos( $lower, 'say' ) !== false ) && preg_match( '/["\']([^"\']+)["\']/', $prompt, $tm ) ) {
			$new_text              = $tm[1];
			$plan['dom_patches'][] = array(
				'type'     => 'replace_text',
				'selector' => $selector,
				'content'  => $new_text,
				'position' => 'replace',
				'style'    => '',
				'scope'    => 'global',
			);
			$matched_descriptions[] = sprintf( __( 'replaced text on `%1$s` with "%2$s"', 'safe-ui-adjuster' ), $selector, $new_text );
		}

		// 9. Gutenberg & Admin Role Tweaks via Chat (e.g., "Hide comments menu and embed blocks for authors and contributors")
		$target_roles = array();
		foreach ( array( 'editor', 'author', 'contributor', 'subscriber' ) as $r ) {
			if ( strpos( $lower, $r ) !== false ) {
				$target_roles[] = $r;
			}
		}
		if ( empty( $target_roles ) && ( strpos( $lower, 'non-admin' ) !== false || strpos( $lower, 'Gutenberg' ) !== false || strpos( $lower, 'menu' ) !== false || strpos( $lower, 'panel' ) !== false || strpos( $lower, 'block' ) !== false ) ) {
			$target_roles = array( 'author', 'contributor' );
		}

		if ( ! empty( $target_roles ) ) {
			$menus_to_hide  = array();
			$panels_to_hide = array();
			$blocks_to_hide = array();

			if ( strpos( $lower, 'comment' ) !== false ) {
				$menus_to_hide[]  = 'edit-comments.php';
				$panels_to_hide[] = 'discussion-panel';
			}
			if ( strpos( $lower, 'tool' ) !== false ) {
				$menus_to_hide[] = 'tools.php';
			}
			if ( strpos( $lower, 'plugin' ) !== false ) {
				$menus_to_hide[] = 'plugins.php';
			}
			if ( strpos( $lower, 'setting' ) !== false ) {
				$menus_to_hide[] = 'options-general.php';
			}
			if ( strpos( $lower, 'excerpt' ) !== false ) {
				$panels_to_hide[] = 'post-excerpt';
			}
			if ( strpos( $lower, 'featured image' ) !== false ) {
				$panels_to_hide[] = 'featured-image';
			}
			if ( strpos( $lower, 'tag' ) !== false ) {
				$panels_to_hide[] = 'taxonomy-panel-post_tag';
			}
			if ( strpos( $lower, 'embed' ) !== false ) {
				$blocks_to_hide[] = 'core/embed';
			}
			if ( strpos( $lower, 'html block' ) !== false || strpos( $lower, 'custom html' ) !== false ) {
				$blocks_to_hide[] = 'core/html';
			}

			if ( ! empty( $menus_to_hide ) || ! empty( $panels_to_hide ) || ! empty( $blocks_to_hide ) ) {
				foreach ( $target_roles as $role_key ) {
					$plan['role_ui_rules'][ $role_key ] = array(
						'hide_menus'  => $menus_to_hide,
						'hide_panels' => $panels_to_hide,
						'hide_blocks' => $blocks_to_hide,
					);
				}
				$matched_descriptions[] = sprintf(
					__( 'updated Gutenberg & Admin UI restrictions for roles: %s', 'safe-ui-adjuster' ),
					implode( ', ', $target_roles )
				);
			}
		}

		// 10. Direct raw CSS block in prompt if user pasted CSS like ".my-class { color: red; }"
		if ( empty( $matched_descriptions ) && strpos( $prompt, '{' ) !== false && strpos( $prompt, '}' ) !== false ) {
			$plan['css_rules'][]    = array(
				'label' => 'Custom CSS via Chat',
				'scope' => 'global',
				'css'   => $prompt,
			);
			$matched_descriptions[] = __( 'validated and applied your custom CSS block', 'safe-ui-adjuster' );
		}

		if ( ! empty( $matched_descriptions ) ) {
			$plan['reply'] = sprintf(
				/* translators: %s: list of actions performed */
				__( 'Done! I have %s. You can preview the result live or click "Undo" on this message at any time.', 'safe-ui-adjuster' ),
				implode( ', and ', $matched_descriptions )
			);
		} else {
			$tip = empty( $selector )
				? __( 'Tip: Click the Crosshair icon to select any element on the page first, or connect your Gemini / OpenAI / Claude API key in Settings for open-ended AI design generation.', 'safe-ui-adjuster' )
				: sprintf( __( 'You have `%s` selected. Try commands like: "Hide this element", "Change background color to #2563eb", "Make font size 20px", "Round corners 12px", or "Change text to \'New Label\'".', 'safe-ui-adjuster' ), $selector );
			$plan['reply'] = __( 'I wasn\'t able to match a specific local UI rule from that phrasing. ', 'safe-ui-adjuster' ) . $tip;
		}

		return $plan;
	}

	/**
	 * Safely merge an AI or Local structured plan into the active UI state and save a snapshot.
	 *
	 * @param array  $plan          Structured plan array.
	 * @param array  $current_state Current active UI state.
	 * @param string $prompt_label  User prompt for snapshot history label.
	 * @return array                [ 'new_state', 'reply', 'actions_summary', 'snapshot_id' ]
	 */
	private static function apply_structured_plan( $plan, $current_state, $prompt_label ) {
		$new_state       = $current_state;
		$actions_summary = array();

		if ( ! empty( $plan['clear_all'] ) ) {
			$default                 = WSUA_Safety_Guard::get_default_state();
			$default['deploy_mode']  = $current_state['deploy_mode'];
			$snapshot_id             = WSUA_Safety_Guard::save_state_with_snapshot( $default, 'Reset all UI adjustments' );
			return array(
				'new_state'       => $default,
				'reply'           => ! empty( $plan['reply'] ) ? $plan['reply'] : __( 'All UI adjustments reset.', 'safe-ui-adjuster' ),
				'actions_summary' => array( __( 'Reset all CSS, DOM, and Role UI adjustments', 'safe-ui-adjuster' ) ),
				'snapshot_id'     => $snapshot_id,
			);
		}

		// 1. Merge visual design tokens
		if ( ! empty( $plan['tokens'] ) && is_array( $plan['tokens'] ) ) {
			$scalar_tokens = array( 'max_width', 'accent_color', 'bg_color', 'text_color', 'base_font_size', 'font_family' );
			foreach ( $scalar_tokens as $tk ) {
				if ( ! empty( $plan['tokens'][ $tk ] ) ) {
					$val                           = sanitize_text_field( $plan['tokens'][ $tk ] );
					$new_state['tokens'][ $tk ]    = $val;
					$actions_summary[]             = sprintf( 'Token %s → %s', $tk, $val );
				}
			}
			if ( isset( $plan['tokens']['sticky_header'] ) && null !== $plan['tokens']['sticky_header'] ) {
				$new_state['tokens']['sticky_header'] = (bool) $plan['tokens']['sticky_header'];
				$actions_summary[]                    = 'Sticky Header → ' . ( $new_state['tokens']['sticky_header'] ? 'Enabled' : 'Disabled' );
			}
			if ( ! empty( $plan['tokens']['hide_selectors'] ) && is_array( $plan['tokens']['hide_selectors'] ) ) {
				foreach ( $plan['tokens']['hide_selectors'] as $raw_sel ) {
					$clean_sel = WSUA_Safety_Guard::sanitize_selector( $raw_sel );
					if ( ! empty( $clean_sel ) && ! in_array( $clean_sel, $new_state['tokens']['hide_selectors'], true ) ) {
						$new_state['tokens']['hide_selectors'][] = $clean_sel;
						$actions_summary[]                       = 'Hide Element → ' . $clean_sel;
					}
				}
			}
		}

		// 2. Validate and add CSS Rules
		if ( ! empty( $plan['css_rules'] ) && is_array( $plan['css_rules'] ) ) {
			foreach ( $plan['css_rules'] as $rule ) {
				if ( empty( $rule['css'] ) ) {
					continue;
				}
				$validation = WSUA_Safety_Guard::validate_and_sanitize_css( $rule['css'] );
				if ( ! $validation['valid'] ) {
					$plan['reply'] .= ' [' . $validation['error'] . ']';
					continue;
				}
				$label = ! empty( $rule['label'] ) ? sanitize_text_field( $rule['label'] ) : 'AI CSS Adjustment';
				$new_state['css_rules'][] = array(
					'id'         => 'css_' . uniqid(),
					'label'      => $label,
					'scope'      => ! empty( $rule['scope'] ) ? sanitize_key( $rule['scope'] ) : 'global',
					'css'        => $validation['css'],
					'created_at' => current_time( 'mysql' ),
				);
				$actions_summary[] = 'CSS Rule: ' . $label;
			}
		}

		// 3. Sanitize and add non-destructive DOM Content Patches
		if ( ! empty( $plan['dom_patches'] ) && is_array( $plan['dom_patches'] ) ) {
			foreach ( $plan['dom_patches'] as $patch ) {
				$type     = ! empty( $patch['type'] ) ? sanitize_key( $patch['type'] ) : 'replace_text';
				$selector = ! empty( $patch['selector'] ) ? WSUA_Safety_Guard::sanitize_selector( $patch['selector'] ) : 'body';
				if ( empty( $selector ) ) {
					$selector = 'body';
				}
				$content  = isset( $patch['content'] ) ? wp_kses_post( $patch['content'] ) : '';
				$style    = isset( $patch['style'] ) ? sanitize_text_field( $patch['style'] ) : '';
				$position = ! empty( $patch['position'] ) ? sanitize_key( $patch['position'] ) : 'top';

				$new_state['dom_patches'][] = array(
					'id'       => 'dom_' . uniqid(),
					'type'     => $type,
					'selector' => $selector,
					'content'  => $content,
					'position' => $position,
					'style'    => $style,
					'scope'    => ! empty( $patch['scope'] ) ? sanitize_key( $patch['scope'] ) : 'global',
				);
				$actions_summary[] = sprintf( 'DOM Patch (%s) on %s', $type, $selector );
			}
		}

		// 4. Merge Gutenberg & Role-Based Admin UI Rules
		if ( ! empty( $plan['role_ui_rules'] ) && is_array( $plan['role_ui_rules'] ) ) {
			foreach ( $plan['role_ui_rules'] as $role => $rules ) {
				$role = sanitize_key( $role );
				// Never allow restricting Administrator role to prevent lockout
				if ( 'administrator' === $role || ! isset( $new_state['role_ui_rules'][ $role ] ) ) {
					continue;
				}
				foreach ( array( 'hide_menus', 'hide_panels', 'hide_blocks' ) as $list_key ) {
					if ( ! empty( $rules[ $list_key ] ) && is_array( $rules[ $list_key ] ) ) {
						$existing = isset( $new_state['role_ui_rules'][ $role ][ $list_key ] ) ? $new_state['role_ui_rules'][ $role ][ $list_key ] : array();
						$merged   = array_values( array_unique( array_merge( $existing, array_map( 'sanitize_text_field', $rules[ $list_key ] ) ) ) );
						$new_state['role_ui_rules'][ $role ][ $list_key ] = $merged;
					}
				}
				$actions_summary[] = 'Updated Role UI Rules for ' . ucfirst( $role );
			}
		}

		$snapshot_id = '';
		if ( ! empty( $actions_summary ) ) {
			$snapshot_id = WSUA_Safety_Guard::save_state_with_snapshot( $new_state, wp_trim_words( $prompt_label, 10, '...' ) );
		}

		return array(
			'new_state'       => $new_state,
			'reply'           => ! empty( $plan['reply'] ) ? $plan['reply'] : __( 'UI adjustment applied.', 'safe-ui-adjuster' ),
			'actions_summary' => $actions_summary,
			'snapshot_id'     => $snapshot_id,
		);
	}
}
