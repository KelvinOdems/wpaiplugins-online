<?php
/**
 * 4-Layer "Zero-Breakage" Safety Guard:
 * 1. Emergency URL kill-switch (?wsua_safe_mode=1) and wp-config constant WSUA_SAFE_MODE.
 * 2. Admin-Only Preview Staging Mode vs. Live Mode.
 * 3. CSS & DOM Patch Sanitizer (balanced braces {}, strips <script>, </style>, @import).
 * 4. 20-Turn Snapshot History with 1-Click Per-Message Undo / Rollback.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_Safety_Guard {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'handle_safe_mode_cookie' ), 1 );
	}

	/**
	 * Allow ?wsua_safe_mode=1 to set a session cookie or ?wsua_safe_mode=0 to exit safe mode.
	 */
	public static function handle_safe_mode_cookie() {
		if ( isset( $_GET['wsua_safe_mode'] ) ) {
			$val = sanitize_text_field( wp_unslash( $_GET['wsua_safe_mode'] ) );
			if ( '1' === $val ) {
				setcookie( 'wsua_safe_mode_active', '1', time() + HOUR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
				$_COOKIE['wsua_safe_mode_active'] = '1';
			} elseif ( '0' === $val ) {
				setcookie( 'wsua_safe_mode_active', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
				unset( $_COOKIE['wsua_safe_mode_active'] );
			}
		}
	}

	/**
	 * Check if Emergency Safe Mode bypass is active.
	 *
	 * @return bool
	 */
	public static function is_safe_mode_active() {
		if ( defined( 'WSUA_SAFE_MODE' ) && WSUA_SAFE_MODE ) {
			return true;
		}
		if ( isset( $_GET['wsua_safe_mode'] ) && '1' === $_GET['wsua_safe_mode'] ) {
			return true;
		}
		if ( ! empty( $_COOKIE['wsua_safe_mode_active'] ) && '1' === $_COOKIE['wsua_safe_mode_active'] ) {
			return true;
		}
		return false;
	}

	/**
	 * Check if UI adjustments should be rendered for the current visitor.
	 *
	 * @return bool
	 */
	public static function should_apply_adjustments() {
		if ( self::is_safe_mode_active() ) {
			return false;
		}

		$state = self::get_active_state();
		$mode  = isset( $state['deploy_mode'] ) ? $state['deploy_mode'] : 'preview';

		// In 'preview' mode, only logged-in Administrators see the adjustments.
		if ( 'preview' === $mode && ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Return the default empty UI state structure.
	 *
	 * @return array
	 */
	public static function get_default_state() {
		return array(
			'deploy_mode'   => 'preview', // 'preview' (Admin only) or 'live' (All visitors)
			'tokens'        => array(
				'max_width'       => '',
				'accent_color'    => '',
				'bg_color'        => '',
				'text_color'      => '',
				'base_font_size'  => '',
				'font_family'     => '',
				'sticky_header'   => false,
				'hide_selectors'  => array(),
			),
			'css_rules'     => array(), // Array of [ 'id', 'label', 'scope', 'css', 'created_at' ]
			'dom_patches'   => array(), // Array of [ 'id', 'type', 'selector', 'content', 'position', 'style', 'scope' ]
			'role_ui_rules' => array(
				'editor'      => array( 'hide_menus' => array(), 'hide_panels' => array(), 'hide_blocks' => array() ),
				'author'      => array( 'hide_menus' => array(), 'hide_panels' => array(), 'hide_blocks' => array() ),
				'contributor' => array( 'hide_menus' => array(), 'hide_panels' => array(), 'hide_blocks' => array() ),
				'subscriber'  => array( 'hide_menus' => array(), 'hide_panels' => array(), 'hide_blocks' => array() ),
			),
			'updated_at'    => current_time( 'mysql' ),
		);
	}

	/**
	 * Retrieve current active UI state merged with defaults.
	 *
	 * @return array
	 */
	public static function get_active_state() {
		$saved    = get_option( WSUA_OPT_ACTIVE_STATE, array() );
		$defaults = self::get_default_state();
		if ( ! is_array( $saved ) || empty( $saved ) ) {
			return $defaults;
		}

		$merged                  = wp_parse_args( $saved, $defaults );
		$merged['tokens']        = wp_parse_args( isset( $saved['tokens'] ) ? $saved['tokens'] : array(), $defaults['tokens'] );
		$merged['role_ui_rules'] = wp_parse_args( isset( $saved['role_ui_rules'] ) ? $saved['role_ui_rules'] : array(), $defaults['role_ui_rules'] );
		return $merged;
	}

	/**
	 * Validate and sanitize CSS string for balanced braces and no breakout tags.
	 *
	 * @param string $css Raw CSS string.
	 * @return array [ 'valid' => bool, 'css' => string, 'error' => string ]
	 */
	public static function validate_and_sanitize_css( $css ) {
		$css = trim( (string) $css );
		if ( '' === $css ) {
			return array(
				'valid' => true,
				'css'   => '',
				'error' => '',
			);
		}

		// Strip any HTML <style> or <script> tags that an LLM or user might include.
		$css = preg_replace( '#</?(style|script)[^>]*>#i', '', $css );

		// Block external @import or javascript: URLs in CSS.
		$css = preg_replace( '/@import\s+[^;]+;/i', '/* @import blocked by Safety Guard */', $css );
		$css = preg_replace( '/javascript\s*:/i', '', $css );
		$css = preg_replace( '/expression\s*\(/i', '', $css );

		// Check balanced curly braces { and }
		$open_count  = substr_count( $css, '{' );
		$close_count = substr_count( $css, '}' );
		if ( $open_count !== $close_count ) {
			return array(
				'valid' => false,
				'css'   => $css,
				'error' => sprintf(
					/* translators: 1: open braces count, 2: close braces count */
					__( 'CSS Syntax Guard Blocked Change: Unbalanced curly braces (%1$d opening "{" vs %2$d closing "}").', 'safe-ui-adjuster' ),
					$open_count,
					$close_count
				),
			);
		}

		// Prevent accidental hiding of the entire html/body or our own chat drawer
		if ( preg_match( '/\b(html|body)\s*\{[^}]*display\s*:\s*none/i', $css ) ) {
			return array(
				'valid' => false,
				'css'   => $css,
				'error' => __( 'Safety Guard Blocked Change: Hiding the root html or body element is forbidden to prevent blank-screen lockouts.', 'safe-ui-adjuster' ),
			);
		}

		return array(
			'valid' => true,
			'css'   => $css,
			'error' => '',
		);
	}

	/**
	 * Sanitize a CSS selector string.
	 *
	 * @param string $selector Raw selector.
	 * @return string
	 */
	public static function sanitize_selector( $selector ) {
		$selector = trim( wp_strip_all_tags( (string) $selector ) );
		// Prevent targeting our own chat drawer or admin studio UI
		if ( stripos( $selector, 'wsua-' ) !== false || in_array( strtolower( $selector ), array( 'html', 'body', '#wpadminbar' ), true ) ) {
			return '';
		}
		return preg_replace( '/[^a-zA-Z0-9_\-\.\#\s>\+\~\:\[\]\=\"\'\(\),\*]/', '', $selector );
	}

	/**
	 * Save a new UI state and record a snapshot for 1-click Undo.
	 *
	 * @param array  $new_state New state array.
	 * @param string $label     Human-readable summary of the change (e.g. chat prompt or action summary).
	 * @return string           Snapshot ID created before this change.
	 */
	public static function save_state_with_snapshot( $new_state, $label = 'UI Adjustment' ) {
		$current_state = self::get_active_state();
		$snapshots     = get_option( WSUA_OPT_SNAPSHOTS, array() );
		if ( ! is_array( $snapshots ) ) {
			$snapshots = array();
		}

		$snapshot_id = 'snap_' . uniqid();
		array_unshift(
			$snapshots,
			array(
				'id'         => $snapshot_id,
				'label'      => sanitize_text_field( $label ),
				'created_at' => current_time( 'mysql' ),
				'state'      => $current_state,
			)
		);

		// Keep last 20 snapshots
		$snapshots = array_slice( $snapshots, 0, 20 );
		update_option( WSUA_OPT_SNAPSHOTS, $snapshots, false );

		$new_state['updated_at'] = current_time( 'mysql' );
		update_option( WSUA_OPT_ACTIVE_STATE, $new_state, false );

		return $snapshot_id;
	}

	/**
	 * Restore a specific snapshot by ID.
	 *
	 * @param string $snapshot_id Snapshot ID to restore.
	 * @return array|WP_Error     Restored state or WP_Error.
	 */
	public static function restore_snapshot( $snapshot_id ) {
		$snapshots = get_option( WSUA_OPT_SNAPSHOTS, array() );
		if ( ! is_array( $snapshots ) ) {
			return new WP_Error( 'wsua_no_snapshots', __( 'No snapshots found.', 'safe-ui-adjuster' ) );
		}

		foreach ( $snapshots as $snap ) {
			if ( isset( $snap['id'] ) && $snap['id'] === $snapshot_id && isset( $snap['state'] ) ) {
				update_option( WSUA_OPT_ACTIVE_STATE, $snap['state'], false );
				return $snap['state'];
			}
		}

		return new WP_Error( 'wsua_snapshot_not_found', __( 'Requested snapshot ID was not found in history.', 'safe-ui-adjuster' ) );
	}
}
