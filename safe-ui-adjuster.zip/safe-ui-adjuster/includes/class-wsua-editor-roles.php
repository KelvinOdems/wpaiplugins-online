<?php
/**
 * Gutenberg Block Editor & Role-Based Admin UI Controller:
 * Enforces role-specific menu hiding, Gutenberg panel removals, and block restrictions
 * configured either via Chat ("Hide Comments menu and Embed blocks for Authors") or the Admin Studio UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_Editor_Roles {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'apply_role_admin_menu_restrictions' ), 999 );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'enqueue_gutenberg_role_tweaks' ) );
	}

	/**
	 * Get the restriction rules matching the current logged-in user's role.
	 * Administrators are ALWAYS exempt to prevent lockout.
	 *
	 * @return array|null
	 */
	public static function get_current_user_role_rules() {
		if ( WSUA_Safety_Guard::is_safe_mode_active() ) {
			return null;
		}

		// Administrators are never restricted
		if ( current_user_can( 'manage_options' ) ) {
			return null;
		}

		$user = wp_get_current_user();
		if ( ! $user || empty( $user->roles ) ) {
			return null;
		}

		$state      = WSUA_Safety_Guard::get_active_state();
		$role_rules = isset( $state['role_ui_rules'] ) ? $state['role_ui_rules'] : array();

		foreach ( $user->roles as $role_slug ) {
			if ( ! empty( $role_rules[ $role_slug ] ) ) {
				return $role_rules[ $role_slug ];
			}
		}

		return null;
	}

	/**
	 * Hide restricted top-level WP Admin menu pages for non-admin roles.
	 */
	public static function apply_role_admin_menu_restrictions() {
		$rules = self::get_current_user_role_rules();
		if ( empty( $rules ) || empty( $rules['hide_menus'] ) || ! is_array( $rules['hide_menus'] ) ) {
			return;
		}

		foreach ( $rules['hide_menus'] as $menu_slug ) {
			remove_menu_page( sanitize_text_field( $menu_slug ) );
		}
	}

	/**
	 * Enqueue Gutenberg Block Editor UI restrictions for the current user role.
	 */
	public static function enqueue_gutenberg_role_tweaks() {
		$rules = self::get_current_user_role_rules();
		if ( empty( $rules ) ) {
			return;
		}

		if ( empty( $rules['hide_panels'] ) && empty( $rules['hide_blocks'] ) ) {
			return;
		}

		wp_enqueue_script(
			'wsua-gutenberg-tweaks',
			WSUA_PLUGIN_URL . 'assets/js/gutenberg-tweaks.js',
			array( 'wp-blocks', 'wp-dom-ready', 'wp-edit-post', 'wp-data' ),
			WSUA_VERSION,
			true
		);

		wp_localize_script(
			'wsua-gutenberg-tweaks',
			'WSUA_EditorRules',
			array(
				'hidePanels' => isset( $rules['hide_panels'] ) ? array_values( $rules['hide_panels'] ) : array(),
				'hideBlocks' => isset( $rules['hide_blocks'] ) ? array_values( $rules['hide_blocks'] ) : array(),
			)
		);
	}
}
