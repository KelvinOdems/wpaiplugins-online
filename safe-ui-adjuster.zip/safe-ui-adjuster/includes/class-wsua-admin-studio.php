<?php
/**
 * Dedicated Split-Screen AI Chat Studio in WP Admin + AJAX Endpoints for Chat, Rollback, and Settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WSUA_Admin_Studio {

	/**
	 * Initialize admin hooks and AJAX handlers.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );

		// Shared AJAX handlers for both Frontend Floating Drawer & Admin Split-Screen Studio
		add_action( 'wp_ajax_wsua_send_chat', array( __CLASS__, 'ajax_send_chat' ) );
		add_action( 'wp_ajax_wsua_undo_snapshot', array( __CLASS__, 'ajax_undo_snapshot' ) );
		add_action( 'wp_ajax_wsua_toggle_deploy_mode', array( __CLASS__, 'ajax_toggle_deploy_mode' ) );
		add_action( 'wp_ajax_wsua_save_ai_settings', array( __CLASS__, 'ajax_save_ai_settings' ) );
		add_action( 'wp_ajax_wsua_delete_rule_item', array( __CLASS__, 'ajax_delete_rule_item' ) );
	}

	/**
	 * Register WP Safe UI Studio menu in WP Admin.
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'WP Safe UI — AI Studio', 'safe-ui-adjuster' ),
			__( 'WP Safe UI AI', 'safe-ui-adjuster' ),
			'manage_options',
			'safe-ui-adjuster',
			array( __CLASS__, 'render_studio_page' ),
			'dashicons-art',
			82
		);
	}

	/**
	 * Enqueue Admin Studio styles and scripts.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'toplevel_page_wp-safe-ui-adjuster' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'wsua-admin-studio-css',
			WSUA_PLUGIN_URL . 'assets/css/admin-studio.css',
			array(),
			WSUA_VERSION
		);

		wp_enqueue_script(
			'wsua-admin-studio-js',
			WSUA_PLUGIN_URL . 'assets/js/admin-studio.js',
			array( 'jquery' ),
			WSUA_VERSION,
			true
		);

		$state     = WSUA_Safety_Guard::get_active_state();
		$history   = get_option( WSUA_OPT_CHAT_HISTORY, array() );
		$snapshots = get_option( WSUA_OPT_SNAPSHOTS, array() );

		wp_localize_script(
			'wsua-admin-studio-js',
			'WSUA_StudioConfig',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'wsua_chat_nonce' ),
				'previewUrl' => add_query_arg( 'wsua_studio_preview', '1', home_url( '/' ) ),
				'state'      => $state,
				'history'    => is_array( $history ) ? $history : array(),
				'snapshots'  => is_array( $snapshots ) ? array_slice( $snapshots, 0, 15 ) : array(),
			)
		);
	}

	/**
	 * Verify administrator permission and nonce.
	 */
	private static function verify_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'safe-ui-adjuster' ) ), 403 );
		}
		check_ajax_referer( 'wsua_chat_nonce', 'nonce' );
	}

	/**
	 * AJAX: Process an AI Chat prompt and return updated CSS, DOM patches, and snapshot ID.
	 */
	public static function ajax_send_chat() {
		self::verify_request();

		$prompt = isset( $_POST['prompt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['prompt'] ) ) : '';
		if ( empty( $prompt ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a message.', 'safe-ui-adjuster' ) ) );
		}

		$selected = array();
		if ( ! empty( $_POST['selected_element'] ) ) {
			$raw_sel = json_decode( sanitize_text_field( wp_unslash( $_POST['selected_element'] ) ), true );
			if ( is_array( $raw_sel ) ) {
				$selected = array(
					'selector' => isset( $raw_sel['selector'] ) ? WSUA_Safety_Guard::sanitize_selector( $raw_sel['selector'] ) : '',
					'tagName'  => isset( $raw_sel['tagName'] ) ? sanitize_text_field( $raw_sel['tagName'] ) : '',
					'text'     => isset( $raw_sel['text'] ) ? sanitize_text_field( substr( $raw_sel['text'], 0, 120 ) ) : '',
				);
			}
		}

		$page_ctx = array();
		if ( ! empty( $_POST['page_context'] ) ) {
			$raw_ctx = json_decode( sanitize_text_field( wp_unslash( $_POST['page_context'] ) ), true );
			if ( is_array( $raw_ctx ) ) {
				$page_ctx = $raw_ctx;
			}
		}

		$result    = WSUA_AI_Agent::handle_chat_turn( $prompt, $selected, $page_ctx );
		$snapshots = get_option( WSUA_OPT_SNAPSHOTS, array() );

		wp_send_json_success(
			array(
				'turn'         => $result['turn'],
				'state'        => $result['state'],
				'compiled_css' => $result['compiled_css'],
				'dom_patches'  => $result['dom_patches'],
				'snapshots'    => array_slice( is_array( $snapshots ) ? $snapshots : array(), 0, 15 ),
			)
		);
	}

	/**
	 * AJAX: 1-Click Undo / Restore a specific snapshot ID.
	 */
	public static function ajax_undo_snapshot() {
		self::verify_request();

		$snap_id  = isset( $_POST['snapshot_id'] ) ? sanitize_text_field( wp_unslash( $_POST['snapshot_id'] ) ) : '';
		$restored = WSUA_Safety_Guard::restore_snapshot( $snap_id );

		if ( is_wp_error( $restored ) ) {
			wp_send_json_error( array( 'message' => $restored->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message'      => __( 'Reverted UI state to snapshot!', 'safe-ui-adjuster' ),
				'state'        => $restored,
				'compiled_css' => WSUA_Runtime_Engine::compile_frontend_css( $restored ),
				'dom_patches'  => $restored['dom_patches'],
			)
		);
	}

	/**
	 * AJAX: Switch between 'preview' (Admin-only) and 'live' (All visitors).
	 */
	public static function ajax_toggle_deploy_mode() {
		self::verify_request();

		$state                = WSUA_Safety_Guard::get_active_state();
		$new_mode             = ( 'live' === $state['deploy_mode'] ) ? 'preview' : 'live';
		$state['deploy_mode'] = $new_mode;

		update_option( WSUA_OPT_ACTIVE_STATE, $state, false );

		wp_send_json_success(
			array(
				'deploy_mode' => $new_mode,
				'message'     => ( 'live' === $new_mode )
					? __( 'Published LIVE! All site visitors now see your UI adjustments.', 'safe-ui-adjuster' )
					: __( 'Switched to Admin Preview Mode. Only logged-in Administrators see your adjustments.', 'safe-ui-adjuster' ),
			)
		);
	}

	/**
	 * AJAX: Delete an individual CSS rule, DOM patch, or hidden selector from the Inspector tab.
	 */
	public static function ajax_delete_rule_item() {
		self::verify_request();

		$kind  = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
		$id    = isset( $_POST['item_id'] ) ? sanitize_text_field( wp_unslash( $_POST['item_id'] ) ) : '';
		$state = WSUA_Safety_Guard::get_active_state();

		if ( 'css_rule' === $kind ) {
			$state['css_rules'] = array_values(
				array_filter(
					$state['css_rules'],
					function ( $r ) use ( $id ) {
						return isset( $r['id'] ) && $r['id'] !== $id;
					}
				)
			);
		} elseif ( 'dom_patch' === $kind ) {
			$state['dom_patches'] = array_values(
				array_filter(
					$state['dom_patches'],
					function ( $p ) use ( $id ) {
						return isset( $p['id'] ) && $p['id'] !== $id;
					}
				)
			);
		} elseif ( 'hide_selector' === $kind ) {
			$state['tokens']['hide_selectors'] = array_values(
				array_filter(
					$state['tokens']['hide_selectors'],
					function ( $s ) use ( $id ) {
						return $s !== $id;
					}
				)
			);
		}

		WSUA_Safety_Guard::save_state_with_snapshot( $state, 'Removed ' . $kind . ' (' . $id . ')' );

		wp_send_json_success(
			array(
				'state'        => $state,
				'compiled_css' => WSUA_Runtime_Engine::compile_frontend_css( $state ),
				'dom_patches'  => $state['dom_patches'],
			)
		);
	}

	/**
	 * AJAX: Save AI Provider (Gemini / OpenAI / Claude) and Encrypted API Keys.
	 */
	public static function ajax_save_ai_settings() {
		self::verify_request();

		$existing = WSUA_AI_Agent::get_settings();
		$provider = isset( $_POST['provider'] ) && in_array( $_POST['provider'], array( 'gemini', 'openai', 'claude' ), true )
			? sanitize_key( $_POST['provider'] )
			: 'gemini';

		$new_settings = array(
			'provider'          => $provider,
			'gemini_model'      => isset( $_POST['gemini_model'] ) ? sanitize_text_field( wp_unslash( $_POST['gemini_model'] ) ) : 'gemini-2.5-flash',
			'openai_model'      => isset( $_POST['openai_model'] ) ? sanitize_text_field( wp_unslash( $_POST['openai_model'] ) ) : 'gpt-4o-mini',
			'claude_model'      => isset( $_POST['claude_model'] ) ? sanitize_text_field( wp_unslash( $_POST['claude_model'] ) ) : 'claude-3-7-sonnet-latest',
			'gemini_key_enc'    => $existing['gemini_key_enc'],
			'openai_key_enc'    => $existing['openai_key_enc'],
			'claude_key_enc'    => $existing['claude_key_enc'],
			'enable_front_chat' => ! empty( $_POST['enable_front_chat'] ),
		);

		foreach ( array( 'gemini', 'openai', 'claude' ) as $p ) {
			$raw_key = isset( $_POST[ $p . '_key' ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $p . '_key' ] ) ) ) : '';
			if ( ! empty( $raw_key ) && '••••••••••••••••' !== $raw_key ) {
				$new_settings[ $p . '_key_enc' ] = WSUA_Crypto::encrypt( $raw_key );
			}
		}

		update_option( WSUA_OPT_SETTINGS, $new_settings, false );

		wp_send_json_success(
			array(
				'message'  => __( 'AI Provider settings & encrypted API keys saved!', 'safe-ui-adjuster' ),
				'provider' => $provider,
			)
		);
	}

	/**
	 * Render the Split-Screen AI Chat Studio in WP Admin.
	 */
	public static function render_studio_page() {
		$settings    = WSUA_AI_Agent::get_settings();
		$state       = WSUA_Safety_Guard::get_active_state();
		$is_live     = ( 'live' === $state['deploy_mode'] );
		$preview_url = add_query_arg( 'wsua_studio_preview', '1', home_url( '/' ) );
		?>
		<div class="wrap wsua-studio-wrap">
			<h1 class="wp-heading-inline screen-reader-text"><?php esc_html_e( 'WP Safe UI Adjuster', 'safe-ui-adjuster' ); ?></h1>
			<hr class="wp-header-end">

			<!-- Top Studio Bar -->
			<div class="wsua-studio-topbar">
				<div class="wsua-brand">
					<span class="wsua-brand-icon">
						<svg class="wsua-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="2" x2="6" y1="14" y2="14"/><line x1="10" x2="14" y1="8" y2="8"/><line x1="18" x2="22" y1="16" y2="16"/></svg>
					</span>
					<div>
						<h2 class="wsua-studio-title"><?php esc_html_e( 'WP Safe UI Adjuster — Conversational AI Studio', 'safe-ui-adjuster' ); ?></h2>
						<p><?php esc_html_e( 'Chat to adjust CSS, layout, DOM banners/text, and Gutenberg role UI with 1-click rollback.', 'safe-ui-adjuster' ); ?></p>
					</div>
				</div>

				<div class="wsua-topbar-actions">
					<div class="wsua-deploy-toggle">
						<span><?php esc_html_e( 'Visibility Mode:', 'safe-ui-adjuster' ); ?></span>
						<button type="button" id="wsua-studio-mode-btn" class="wsua-mode-badge <?php echo $is_live ? 'is-live' : 'is-preview'; ?>">
							<?php echo $is_live ? esc_html__( '● LIVE (All Visitors)', 'safe-ui-adjuster' ) : esc_html__( '◐ PREVIEW (Admins Only)', 'safe-ui-adjuster' ); ?>
						</button>
					</div>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" class="wsua-btn-outline">
						<span><?php esc_html_e( 'Open Live Frontend + Floating Drawer', 'safe-ui-adjuster' ); ?></span>
						<svg class="wsua-svg-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
					</a>
				</div>
			</div>

			<!-- Split-Screen Workspace -->
			<div class="wsua-studio-grid">
				<!-- LEFT PANE: Antigravity-Style Conversational Chat -->
				<div class="wsua-chat-column">
					<div class="wsua-chat-header">
						<strong><?php esc_html_e( 'AI UI Assistant', 'safe-ui-adjuster' ); ?></strong>
						<span class="wsua-engine-pill" id="wsua-active-provider-pill">
							<?php echo esc_html( strtoupper( $settings['provider'] ) ); ?>
						</span>
					</div>

					<div class="wsua-studio-chips">
						<button type="button" class="wsua-studio-chip" data-prompt="Make the header sticky with a blurred glass background"><?php esc_html_e( 'Sticky glass header', 'safe-ui-adjuster' ); ?></button>
						<button type="button" class="wsua-studio-chip" data-prompt="Set max container width to 1240px and button accent color to #2563eb"><?php esc_html_e( '1240px width + Blue buttons', 'safe-ui-adjuster' ); ?></button>
						<button type="button" class="wsua-studio-chip" data-prompt="Add an announcement banner saying 'Special Offer: Free consultation this week!'"><?php esc_html_e( '+ Top Announcement Bar', 'safe-ui-adjuster' ); ?></button>
						<button type="button" class="wsua-studio-chip" data-prompt="Hide comments menu, tools menu, and embed blocks for authors and contributors"><?php esc_html_e( 'Simplify Author Editor UI', 'safe-ui-adjuster' ); ?></button>
					</div>

					<div class="wsua-studio-messages" id="wsua-studio-messages"></div>

					<div class="wsua-studio-selected-bar" id="wsua-studio-selected-bar" style="display:none;">
						<span>@selected in preview: <code id="wsua-studio-selected-code"></code></span>
						<button type="button" id="wsua-studio-clear-sel">✕</button>
					</div>

					<form id="wsua-studio-chat-form" class="wsua-studio-composer">
						<button type="button" id="wsua-studio-pick-btn" class="wsua-picker-btn" title="<?php esc_attr_e( 'Click any element inside the right-hand Live Preview iframe', 'safe-ui-adjuster' ); ?>">
							⊕ <?php esc_html_e( 'Pick Element', 'safe-ui-adjuster' ); ?>
						</button>
						<textarea id="wsua-studio-input" rows="2" placeholder="<?php esc_attr_e( 'Describe any UI adjustment (or click "⊕ Pick Element" then click inside the preview)...', 'safe-ui-adjuster' ); ?>"></textarea>
						<button type="submit" id="wsua-studio-send" class="button button-primary">
							<?php esc_html_e( 'Send ↑', 'safe-ui-adjuster' ); ?>
						</button>
					</form>
				</div>

				<!-- RIGHT PANE: Tabbed Live Preview, Active Rules Inspector,Snapshots, & AI Provider Settings -->
				<div class="wsua-workspace-column">
					<div class="wsua-tabs-bar">
						<div class="wsua-tabs">
							<button type="button" class="wsua-tab active" data-tab="preview"><?php esc_html_e( 'Live Site Preview', 'safe-ui-adjuster' ); ?></button>
							<button type="button" class="wsua-tab" data-tab="inspector"><?php esc_html_e( 'Active UI Rules & Role Guard', 'safe-ui-adjuster' ); ?></button>
							<button type="button" class="wsua-tab" data-tab="snapshots"><?php esc_html_e( 'Snapshot History (Undo)', 'safe-ui-adjuster' ); ?></button>
							<button type="button" class="wsua-tab" data-tab="settings"><?php esc_html_e( 'AI Providers (BYOK)', 'safe-ui-adjuster' ); ?></button>
						</div>
						<div class="wsua-viewport-toggles" id="wsua-viewport-toggles">
							<button type="button" class="wsua-vp-btn active" data-width="100%"><?php esc_html_e( 'Desktop', 'safe-ui-adjuster' ); ?></button>
							<button type="button" class="wsua-vp-btn" data-width="768px"><?php esc_html_e( 'Tablet', 'safe-ui-adjuster' ); ?></button>
							<button type="button" class="wsua-vp-btn" data-width="390px"><?php esc_html_e( 'Mobile', 'safe-ui-adjuster' ); ?></button>
						</div>
					</div>

					<!-- TAB 1: Live Site Iframe Preview -->
					<div class="wsua-tab-panel active" id="wsua-tab-preview">
						<div class="wsua-iframe-container">
							<iframe id="wsua-preview-iframe" src="<?php echo esc_url( $preview_url ); ?>"></iframe>
						</div>
					</div>

					<!-- TAB 2: Active Rules Inspector -->
					<div class="wsua-tab-panel" id="wsua-tab-inspector">
						<div class="wsua-panel-scroll">
							<h3><?php esc_html_e( 'Compiled Virtual CSS Sheet (Injected at wp_head priority 999)', 'safe-ui-adjuster' ); ?></h3>
							<pre class="wsua-code-box" id="wsua-compiled-css-box"><?php echo esc_html( WSUA_Runtime_Engine::compile_frontend_css( $state ) ); ?></pre>

							<h3><?php esc_html_e( 'Active Non-Destructive DOM Content Patches', 'safe-ui-adjuster' ); ?></h3>
							<div id="wsua-dom-patches-list"></div>

							<h3><?php esc_html_e( 'Gutenberg & Role-Based UI Restrictions (Administrators Always Exempt)', 'safe-ui-adjuster' ); ?></h3>
							<pre class="wsua-code-box" id="wsua-role-rules-box"><?php echo esc_html( wp_json_encode( $state['role_ui_rules'], JSON_PRETTY_PRINT ) ); ?></pre>

							<div class="wsua-safety-callout">
								<strong><?php esc_html_e( 'Emergency Bypass URL Kill-Switch:', 'safe-ui-adjuster' ); ?></strong>
								<p>
									<?php esc_html_e( 'Appending ?wsua_safe_mode=1 to any frontend or admin URL immediately suspends all CSS, DOM, and Editor adjustments for your session.', 'safe-ui-adjuster' ); ?>
								</p>
							</div>
						</div>
					</div>

					<!-- TAB 3: Snapshot History -->
					<div class="wsua-tab-panel" id="wsua-tab-snapshots">
						<div class="wsua-panel-scroll">
							<h3><?php esc_html_e( '20-Turn Immutable Snapshot History', 'safe-ui-adjuster' ); ?></h3>
							<p class="wsua-muted"><?php esc_html_e( 'Every chat turn automatically records a snapshot before applying changes. Click "Restore" on any snapshot below to roll back immediately.', 'safe-ui-adjuster' ); ?></p>
							<div id="wsua-snapshots-list"></div>
						</div>
					</div>

					<!-- TAB 4: Multi-Provider BYOK Settings -->
					<div class="wsua-tab-panel" id="wsua-tab-settings">
						<div class="wsua-panel-scroll">
							<h3><?php esc_html_e( 'Multi-Provider AI Engine (Bring Your Own API Key)', 'safe-ui-adjuster' ); ?></h3>
							<p class="wsua-muted">
								<?php esc_html_e( 'Connect Google Gemini, OpenAI, or Anthropic Claude for open-ended natural-language UI generation. Keys are encrypted at rest with AES-256-CBC. Even without a key, the built-in Local Smart Parser handles common commands!', 'safe-ui-adjuster' ); ?>
							</p>
							<form id="wsua-ai-settings-form" class="wsua-settings-form">
								<div class="wsua-field">
									<label><?php esc_html_e( 'Active AI Provider', 'safe-ui-adjuster' ); ?></label>
									<select name="provider" id="wsua-provider-select">
										<option value="gemini" <?php selected( $settings['provider'], 'gemini' ); ?>>Google Gemini (Recommended - Gemini 2.5 Flash / Pro)</option>
										<option value="openai" <?php selected( $settings['provider'], 'openai' ); ?>>OpenAI (GPT-4o / GPT-4o-mini)</option>
										<option value="claude" <?php selected( $settings['provider'], 'claude' ); ?>>Anthropic Claude (Claude 3.7 Sonnet / 3.5 Haiku)</option>
									</select>
								</div>

								<div class="wsua-provider-box">
									<h4>Google Gemini</h4>
									<div class="wsua-field-row">
										<div class="wsua-field">
											<label><?php esc_html_e( 'Gemini API Key', 'safe-ui-adjuster' ); ?></label>
											<input type="password" name="gemini_key" value="<?php echo ! empty( $settings['gemini_key_enc'] ) ? '••••••••••••••••' : ''; ?>" placeholder="AIzaSy..." />
										</div>
										<div class="wsua-field">
											<label><?php esc_html_e( 'Model', 'safe-ui-adjuster' ); ?></label>
											<input type="text" name="gemini_model" value="<?php echo esc_attr( $settings['gemini_model'] ); ?>" />
										</div>
									</div>
								</div>

								<div class="wsua-provider-box">
									<h4>OpenAI</h4>
									<div class="wsua-field-row">
										<div class="wsua-field">
											<label><?php esc_html_e( 'OpenAI API Key', 'safe-ui-adjuster' ); ?></label>
											<input type="password" name="openai_key" value="<?php echo ! empty( $settings['openai_key_enc'] ) ? '••••••••••••••••' : ''; ?>" placeholder="sk-..." />
										</div>
										<div class="wsua-field">
											<label><?php esc_html_e( 'Model', 'safe-ui-adjuster' ); ?></label>
											<input type="text" name="openai_model" value="<?php echo esc_attr( $settings['openai_model'] ); ?>" />
										</div>
									</div>
								</div>

								<div class="wsua-provider-box">
									<h4>Anthropic Claude</h4>
									<div class="wsua-field-row">
										<div class="wsua-field">
											<label><?php esc_html_e( 'Anthropic API Key', 'safe-ui-adjuster' ); ?></label>
											<input type="password" name="claude_key" value="<?php echo ! empty( $settings['claude_key_enc'] ) ? '••••••••••••••••' : ''; ?>" placeholder="sk-ant-..." />
										</div>
										<div class="wsua-field">
											<label><?php esc_html_e( 'Model', 'safe-ui-adjuster' ); ?></label>
											<input type="text" name="claude_model" value="<?php echo esc_attr( $settings['claude_model'] ); ?>" />
										</div>
									</div>
								</div>

								<label class="wsua-checkbox-row">
									<input type="checkbox" name="enable_front_chat" value="1" <?php checked( ! empty( $settings['enable_front_chat'] ) ); ?> />
									<span><?php esc_html_e( 'Enable Floating Live AI Chat Drawer on the Frontend for logged-in Administrators', 'safe-ui-adjuster' ); ?></span>
								</label>

								<button type="submit" class="button button-primary" id="wsua-save-settings-btn">
									<?php esc_html_e( 'Save AI Provider Settings', 'safe-ui-adjuster' ); ?>
								</button>
								<span id="wsua-settings-status" class="wsua-settings-status"></span>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
